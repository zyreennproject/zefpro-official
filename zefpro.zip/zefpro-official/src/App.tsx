/**
 * ZYREENN Official - Central Gaming Mods & eFootball Config
 * One-Page Vertical Flow Architecture
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AdPlacement } from './components/AdPlacement';
import { PatchShowcase } from './components/PatchShowcase';
import { ConfigSection } from './components/ConfigSection';
import { CompatibilityScanner } from './components/CompatibilityScanner';
import { ToolkitSection } from './components/ToolkitSection';
import { FaqSection } from './components/FaqSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { PrivacyModal } from './components/PrivacyModal';
import { CookieBanner } from './components/CookieBanner';

export default function App() {
  // Pengaturan Tema Gelap / Terang (Default Dark Mode untuk Nuansa Gaming)
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('zyreenn_theme');
      if (saved) return saved === 'dark';
      return true; // Default Dark Mode aktif
    }
    return true;
  });

  const [showAdSlots, setShowAdSlots] = useState<boolean>(true);
  const [privacyModalOpen, setPrivacyModalOpen] = useState<boolean>(false);
  const [privacyTab, setPrivacyTab] = useState<'privacy' | 'terms' | 'ads'>('privacy');

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('zyreenn_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('zyreenn_theme', 'light');
    }
  }, [isDark]);

  const toggleTheme = () => {
    setIsDark((prev) => !prev);
  };

  const toggleAdSlots = () => {
    setShowAdSlots((prev) => !prev);
  };

  const handleOpenPrivacy = (tab: 'privacy' | 'terms' | 'ads' = 'privacy') => {
    setPrivacyTab(tab);
    setPrivacyModalOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors selection:bg-red-600 selection:text-white">
      
      {/* 1. Header & Navigasi Utama ZYREENN */}
      <Navbar
        isDark={isDark}
        toggleTheme={toggleTheme}
        showAdSlots={showAdSlots}
        toggleAdSlots={toggleAdSlots}
        onOpenPrivacy={() => handleOpenPrivacy('privacy')}
      />

      {/* ========================================================
          ALUR SATU HALAMAN UTAMA (ONE-PAGE FLOW)
          ======================================================== */}
      <main className="flex-1">
        
        {/* Section 1: Hero Banner, Shimmer Info Ticker + Modal, & Teaser Scanner */}
        <Hero />

        {/* Slot Iklan 1: Leaderboard Atas (Zero CLS Kepatuhan Google AdSense) */}
        <AdPlacement
          format="leaderboard"
          slotId="9823412089"
          placementLabel="Top Leaderboard Header"
          showAdSlots={showAdSlots}
        />

        {/* Section 2: eFootball Patch & Mods (3D Stacked Carousel + Modal Detail) */}
        <PatchShowcase />

        {/* Section 3: Config eFootball (3D Stacked Carousel Lynk.id & Free + Modal Detail) */}
        <ConfigSection />

        {/* Slot Iklan 2: In-Feed Native Banner di Antara Konten */}
        <AdPlacement
          format="infeed"
          slotId="4819203912"
          placementLabel="In-Feed Content Stream"
          showAdSlots={showAdSlots}
        />

        {/* Section 4: Alat Cek Kompatibilitas Chipset (Cyber HUD Laser Scanner) */}
        <CompatibilityScanner />

        {/* Section 5: Toolkit & Aplikasi Pendukung (3D Clean Grid 3 Kolom) */}
        <ToolkitSection />

        {/* Section 6: FAQ Accordion (Keamanan Akun & Banned Safety) */}
        <FaqSection />

        {/* Section 7: Form Konsultasi & Saluran WhatsApp Komunitas */}
        <ContactSection />
      </main>

      {/* 2. Footer Resmi ZYREENN & Disclaimer Konami */}
      <Footer onOpenPrivacy={handleOpenPrivacy} />

      {/* 3. Modal Kepatuhan Kebijakan Privasi & AdSense */}
      <PrivacyModal
        isOpen={privacyModalOpen}
        onClose={() => setPrivacyModalOpen(false)}
        initialTab={privacyTab}
      />

      {/* 4. Banner Persetujuan Cookie */}
      <CookieBanner onOpenPrivacy={() => handleOpenPrivacy('ads')} />

    </div>
  );
}