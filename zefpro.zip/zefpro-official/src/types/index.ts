/* ==========================================================================
   ZYREENN OFFICIAL - TYPE DEFINITIONS (src/types/index.ts)
   Mendukung: 3D Stacked Sliders, Modal Detail, Cyber Chipset Scanner, & Toolkit
   ========================================================================== */

// --- 1. Tipe Data Rincian Modal Pop-Up (Berdasarkan pages-data.js) ---
export interface TutorialStep {
  stepNumber: string;
  title: string;
  desc: string;
}

export interface DetailDownloads {
  nameDownload?: string;
  buttonDownload?: string;
  directUrl?: string;
  mediafire?: string;
  goggledrive?: string;
  pengumuman?: string;
}

export interface ItemDetailData {
  id: string;
  isOrder?: boolean;
  orderUrl?: string; // Tautan pemesanan Lynk.id
  detailSettings: {
    themeColor: string;
    badgeText: string;
    badgeBg: string;
    parentPage?: string;
  };
  header: {
    title: string;
    version: string;
    size: string;
    author: string;
    date: string;
    bannerImg: string;
    shortDesc: string;
  };
  whatsNew: string[];
  featuresList: string[];
  tutorialSteps: TutorialStep[];
  downloads?: DetailDownloads;
  server?: {
    buttonServer: string;
  };
}

// --- 2. Tipe Data Card Slider 3D (Patch, Mods & Config) ---
export interface SliderItem {
  id: string;
  title: string;
  subtitle?: string;
  badge: string;
  image: string;
  detailRefId: string; // Mengarah ke ID ItemDetailData
  isOrder?: boolean;
  orderUrl?: string;
}

// --- 3. Tipe Data Cyber Chipset Compatibility Scanner ---
export type ChipsetTier = 'HIGH' | 'MID' | 'LOW';

export interface ChipsetItem {
  id: string;
  name: string;
  brand: string;
  tier: ChipsetTier;
}

export interface TierRecommendOption {
  type: string;
  nama: string;
  subtext: string;
  preset: string;
  detailRefId: string;
}

export interface TierRecommendation {
  tierBadge: string;
  badgeClass: string;
  deskripsi: string;
  items: TierRecommendOption[];
}

// --- 4. Tipe Data Toolkit 3D Grid (Aplikasi Pendukung) ---
export interface ToolkitItem {
  id: string;
  title: string;
  version: string;
  size: string;
  rating: string;
  iconImg: string;
  shortDesc: string;
  directUrl: string;
  detailRefId: string;
}

// --- 5. Tipe Data Info Ticker, FAQ, & Ads ---
export interface InfoTickerData {
  badgeText: string;
  headline: string;
  modalTitle: string;
  modalContentHtml: string;
}

export interface FaqItem {
  q: string;
  a: string;
}

export interface AdUnitConfig {
  slotId: string;
  format: 'leaderboard' | 'infeed' | 'rectangle';
  placementLabel: string;
}