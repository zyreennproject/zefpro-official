import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateEstimate, formatIDR, PACKAGES, ADD_ONS } from './pricing';

test('calculates base package price without add-ons correctly', () => {
  const result = calculateEstimate('starter', []);
  assert.equal(result.packageItem.id, 'starter');
  assert.equal(result.subtotal, 1750000);
  assert.equal(result.discountPercentage, 0);
  assert.equal(result.discountAmount, 0);
  assert.equal(result.total, 1750000);
  assert.equal(result.estimatedTimelineDays, 3);
});

test('applies bundle discount (10%) when 2 or more add-ons are selected', () => {
  // starter (1,750,000) + addon-seo (450,000) + addon-ads (600,000) = 2,800,000
  const result = calculateEstimate('starter', ['addon-seo', 'addon-ads']);
  assert.equal(result.subtotal, 2800000);
  assert.equal(result.discountPercentage, 10);
  assert.equal(result.discountAmount, 280000);
  assert.equal(result.total, 2520000);
  assert.equal(result.estimatedTimelineDays, 4); // 3 base + 1 extra
});

test('handles fallback to default starter package if invalid id is passed', () => {
  const result = calculateEstimate('non-existent-id', []);
  assert.equal(result.packageItem.id, 'starter');
});

test('formats IDR currency with clean Indonesian locale', () => {
  const formatted = formatIDR(2500000);
  // Should start with Rp and contain 2.500.000
  assert.match(formatted, /Rp/);
  assert.match(formatted, /2\.500\.000/);
});
