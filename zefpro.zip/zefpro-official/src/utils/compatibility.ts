/* ==========================================================================
   ZYREENN OFFICIAL - COMPATIBILITY & CHIPSET ENGINE (src/utils/compatibility.ts)
   Database: 63+ Chipset Android & Logika Rekomendasi Config eFootball
   ========================================================================== */

import { ChipsetItem, ChipsetTier, TierRecommendation } from '../types';

// 1. Kategori Brand Chipset Resmi
export const CHIPSET_BRANDS = [
  "Qualcomm Snapdragon",
  "MediaTek Dimensity & Helio",
  "Samsung Exynos",
  "UNISOC",
  "Google Tensor"
] as const;

// 2. Database Lengkap 63+ Chipset Android
export const CHIPSET_DATABASE: ChipsetItem[] = [
  // --- QUALCOMM SNAPDRAGON ---
  { id: "snapdragon-8-elite-gen-6", name: "Snapdragon 8 Elite Gen 6", brand: "Qualcomm Snapdragon", tier: "HIGH" },
  { id: "snapdragon-8-elite-gen-5", name: "Snapdragon 8 Elite Gen 5", brand: "Qualcomm Snapdragon", tier: "HIGH" },
  { id: "snapdragon-8-elite", name: "Snapdragon 8 Elite", brand: "Qualcomm Snapdragon", tier: "HIGH" },
  { id: "snapdragon-8-gen-5", name: "Snapdragon 8 Gen 5", brand: "Qualcomm Snapdragon", tier: "HIGH" },
  { id: "snapdragon-8-gen-4", name: "Snapdragon 8 Gen 4", brand: "Qualcomm Snapdragon", tier: "HIGH" },
  { id: "snapdragon-8s-gen-4", name: "Snapdragon 8s Gen 4", brand: "Qualcomm Snapdragon", tier: "HIGH" },
  { id: "snapdragon-8-gen-3", name: "Snapdragon 8 Gen 3", brand: "Qualcomm Snapdragon", tier: "HIGH" },
  { id: "snapdragon-8s-gen-3", name: "Snapdragon 8s Gen 3", brand: "Qualcomm Snapdragon", tier: "HIGH" },
  { id: "snapdragon-8-gen-2", name: "Snapdragon 8 Gen 2", brand: "Qualcomm Snapdragon", tier: "HIGH" },
  { id: "snapdragon-7-plus-gen-3", name: "Snapdragon 7+ Gen 3", brand: "Qualcomm Snapdragon", tier: "HIGH" },
  { id: "snapdragon-8-plus-gen-1", name: "Snapdragon 8+ Gen 1", brand: "Qualcomm Snapdragon", tier: "HIGH" },
  { id: "snapdragon-7-plus-gen-2", name: "Snapdragon 7+ Gen 2", brand: "Qualcomm Snapdragon", tier: "HIGH" },
  { id: "snapdragon-888-plus", name: "Snapdragon 888+", brand: "Qualcomm Snapdragon", tier: "MID" },
  { id: "snapdragon-888", name: "Snapdragon 888", brand: "Qualcomm Snapdragon", tier: "MID" },
  { id: "snapdragon-7s-gen-4", name: "Snapdragon 7s Gen 4", brand: "Qualcomm Snapdragon", tier: "MID" },
  { id: "snapdragon-7-gen-4", name: "Snapdragon 7 Gen 4", brand: "Qualcomm Snapdragon", tier: "MID" },
  { id: "snapdragon-6-gen-5", name: "Snapdragon 6 Gen 5", brand: "Qualcomm Snapdragon", tier: "MID" },
  { id: "snapdragon-7s-gen-3", name: "Snapdragon 7s Gen 3", brand: "Qualcomm Snapdragon", tier: "MID" },
  { id: "snapdragon-865-plus", name: "Snapdragon 865+", brand: "Qualcomm Snapdragon", tier: "MID" },
  { id: "snapdragon-870", name: "Snapdragon 870", brand: "Qualcomm Snapdragon", tier: "MID" },
  { id: "snapdragon-7-gen-3", name: "Snapdragon 7 Gen 3", brand: "Qualcomm Snapdragon", tier: "MID" },
  { id: "snapdragon-782g", name: "Snapdragon 782G", brand: "Qualcomm Snapdragon", tier: "MID" },
  { id: "snapdragon-865", name: "Snapdragon 865", brand: "Qualcomm Snapdragon", tier: "MID" },
  { id: "snapdragon-778g", name: "Snapdragon 778G", brand: "Qualcomm Snapdragon", tier: "MID" },
  { id: "snapdragon-6s-gen-3", name: "Snapdragon 6s Gen 3", brand: "Qualcomm Snapdragon", tier: "LOW" },
  { id: "snapdragon-4-gen-5", name: "Snapdragon 4 Gen 5", brand: "Qualcomm Snapdragon", tier: "LOW" },
  { id: "snapdragon-4-gen-2", name: "Snapdragon 4 Gen 2", brand: "Qualcomm Snapdragon", tier: "LOW" },
  { id: "snapdragon-695", name: "Snapdragon 695", brand: "Qualcomm Snapdragon", tier: "LOW" },
  { id: "snapdragon-685", name: "Snapdragon 685", brand: "Qualcomm Snapdragon", tier: "LOW" },
  { id: "snapdragon-680", name: "Snapdragon 680", brand: "Qualcomm Snapdragon", tier: "LOW" },
  { id: "snapdragon-662", name: "Snapdragon 662", brand: "Qualcomm Snapdragon", tier: "LOW" },
  { id: "snapdragon-460", name: "Snapdragon 460", brand: "Qualcomm Snapdragon", tier: "LOW" },

  // --- MEDIATEK DIMENSITY & HELIO ---
  { id: "dimensity-9400-plus", name: "Dimensity 9400+", brand: "MediaTek Dimensity & Helio", tier: "HIGH" },
  { id: "dimensity-9400", name: "Dimensity 9400", brand: "MediaTek Dimensity & Helio", tier: "HIGH" },
  { id: "dimensity-9300-plus", name: "Dimensity 9300+", brand: "MediaTek Dimensity & Helio", tier: "HIGH" },
  { id: "dimensity-9300", name: "Dimensity 9300", brand: "MediaTek Dimensity & Helio", tier: "HIGH" },
  { id: "dimensity-9200-plus", name: "Dimensity 9200+", brand: "MediaTek Dimensity & Helio", tier: "HIGH" },
  { id: "dimensity-9200", name: "Dimensity 9200", brand: "MediaTek Dimensity & Helio", tier: "HIGH" },
  { id: "dimensity-9000-plus", name: "Dimensity 9000+", brand: "MediaTek Dimensity & Helio", tier: "HIGH" },
  { id: "dimensity-9000", name: "Dimensity 9000", brand: "MediaTek Dimensity & Helio", tier: "HIGH" },
  { id: "dimensity-8300", name: "Dimensity 8300", brand: "MediaTek Dimensity & Helio", tier: "MID" },
  { id: "dimensity-8200", name: "Dimensity 8200", brand: "MediaTek Dimensity & Helio", tier: "MID" },
  { id: "dimensity-8100", name: "Dimensity 8100", brand: "MediaTek Dimensity & Helio", tier: "MID" },
  { id: "dimensity-7050", name: "Dimensity 7050", brand: "MediaTek Dimensity & Helio", tier: "MID" },
  { id: "dimensity-7300", name: "Dimensity 7300", brand: "MediaTek Dimensity & Helio", tier: "MID" },
  { id: "dimensity-1080", name: "Dimensity 1080", brand: "MediaTek Dimensity & Helio", tier: "MID" },
  { id: "dimensity-920", name: "Dimensity 920", brand: "MediaTek Dimensity & Helio", tier: "MID" },
  { id: "dimensity-900", name: "Dimensity 900", brand: "MediaTek Dimensity & Helio", tier: "MID" },
  { id: "dimensity-6100-plus", name: "Dimensity 6100+", brand: "MediaTek Dimensity & Helio", tier: "LOW" },
  { id: "dimensity-6020", name: "Dimensity 6020", brand: "MediaTek Dimensity & Helio", tier: "LOW" },
  { id: "dimensity-700", name: "Dimensity 700", brand: "MediaTek Dimensity & Helio", tier: "LOW" },
  { id: "helio-g100", name: "Helio G100", brand: "MediaTek Dimensity & Helio", tier: "LOW" },
  { id: "helio-g99", name: "Helio G99", brand: "MediaTek Dimensity & Helio", tier: "LOW" },
  { id: "helio-g96", name: "Helio G96", brand: "MediaTek Dimensity & Helio", tier: "LOW" },
  { id: "helio-g95", name: "Helio G95", brand: "MediaTek Dimensity & Helio", tier: "LOW" },
  { id: "helio-g88", name: "Helio G88", brand: "MediaTek Dimensity & Helio", tier: "LOW" },
  { id: "helio-g85", name: "Helio G85", brand: "MediaTek Dimensity & Helio", tier: "LOW" },
  { id: "helio-g36", name: "Helio G36", brand: "MediaTek Dimensity & Helio", tier: "LOW" },

  // --- SAMSUNG EXYNOS ---
  { id: "exynos-2400", name: "Exynos 2400", brand: "Samsung Exynos", tier: "HIGH" },
  { id: "exynos-2200", name: "Exynos 2200", brand: "Samsung Exynos", tier: "HIGH" },
  { id: "exynos-1480", name: "Exynos 1480", brand: "Samsung Exynos", tier: "MID" },
  { id: "exynos-1380", name: "Exynos 1380", brand: "Samsung Exynos", tier: "MID" },
  { id: "exynos-1280", name: "Exynos 1280", brand: "Samsung Exynos", tier: "MID" },
  { id: "exynos-850", name: "Exynos 850", brand: "Samsung Exynos", tier: "LOW" },

  // --- UNISOC ---
  { id: "unisoc-t820", name: "UNISOC T820", brand: "UNISOC", tier: "MID" },
  { id: "unisoc-t760", name: "UNISOC T760", brand: "UNISOC", tier: "MID" },
  { id: "unisoc-t616", name: "UNISOC T616", brand: "UNISOC", tier: "LOW" },
  { id: "unisoc-t612", name: "UNISOC T612", brand: "UNISOC", tier: "LOW" },
  { id: "unisoc-t606", name: "UNISOC T606", brand: "UNISOC", tier: "LOW" },

  // --- GOOGLE TENSOR ---
  { id: "tensor-g4", name: "Tensor G4", brand: "Google Tensor", tier: "HIGH" },
  { id: "tensor-g3", name: "Tensor G3", brand: "Google Tensor", tier: "HIGH" },
  { id: "tensor-g2", name: "Tensor G2", brand: "Google Tensor", tier: "MID" },
  { id: "tensor-g1", name: "Tensor G1", brand: "Google Tensor", tier: "MID" }
];

// 3. Peta Rekomendasi Preset Grafik & Config
export const TIER_RECOMMENDATIONS: Record<ChipsetTier, TierRecommendation> = {
  HIGH: {
    tierBadge: "HIGH END",
    badgeClass: "badge-high",
    deskripsi: "Chipset HP kamu tergolong Android High. Semua Config dan Preset dapat berjalan dengan sangat lancar pada performa tertinggi.",
    items: [
      { type: "REKOMENDASI UTAMA", nama: "Config FrameRate Generation V2", subtext: "V6.1.1", preset: "HIGH, MID, LOW", detailRefId: "detail-efconfig-1" },
      { type: "OPSI ALTERNATIF 1", nama: "Config Premium Max", subtext: "V6.1.1", preset: "HIGH, MID, LOW", detailRefId: "detail-efconfig-2" },
      { type: "OPSI ALTERNATIF 2", nama: "Config Extreme Lowest", subtext: "V6.1.1", preset: "NO PRESET", detailRefId: "detail-efconfig-3" },
      { type: "OPSI ALTERNATIF 3", nama: "Config Custom Request", subtext: "V6.1.1", preset: "BEBAS", detailRefId: "detail-efconfig-4" }
    ]
  },
  MID: {
    tierBadge: "MID RANGE",
    badgeClass: "badge-mid",
    deskripsi: "Chipset HP kamu berada di kelas Android Mid. Disarankan menggunakan Preset Grafik Standar atau Rendah 60 FPS untuk menjaga kestabilan framerate dan suhu HP tetap dingin",
    items: [
      { type: "REKOMENDASI UTAMA", nama: "Config Custom Request", subtext: "V6.1.1", preset: "BEBAS", detailRefId: "detail-efconfig-4" },
      { type: "OPSI ALTERNATIF 1", nama: "Config FrameRate Generation V2", subtext: "V6.1.1", preset: "MID, LOW", detailRefId: "detail-efconfig-1" },
      { type: "OPSI ALTERNATIF 2", nama: "Config Premium Max", subtext: "V6.1.1", preset: "MID, LOW", detailRefId: "detail-efconfig-2" },
      { type: "OPSI ALTERNATIF 3", nama: "Config Extreme Lowest", subtext: "V6.1.1", preset: "NO PRESET", detailRefId: "detail-efconfig-3" }
    ]
  },
  LOW: {
    tierBadge: "ENTRY / LOW END",
    badgeClass: "badge-low",
    deskripsi: "Chipset HP kamu berada di kelas Android Low.Rekomendasi utama adalah Config Extreme Lowest agar gameplay 60 FPS bebas lag dan stuttering.",
    items: [
      { type: "REKOMENDASI UTAMA", nama: "Config Extreme Lowest", subtext: "V6.1.1", preset: "NO PRESET", detailRefId: "detail-efconfig-3" },
      { type: "OPSI ALTERNATIF", nama: "Config FrameRate Generation V2", subtext: "V6.1.1", preset: "Wajib Preset LOW", detailRefId: "detail-efconfig-1" }
    ]
  }
};

// 4. Helper Pencarian Chipset Berdasarkan Teks
export function searchChipsets(query: string): ChipsetItem[] {
  if (!query || query.trim() === '') return [];
  const clean = query.toLowerCase().trim();
  return CHIPSET_DATABASE.filter(c => c.name.toLowerCase().includes(clean));
}

// 5. Helper Filter Chipset Berdasarkan Brand
export function getChipsetsByBrand(brand: string): ChipsetItem[] {
  if (!brand) return CHIPSET_DATABASE;
  return CHIPSET_DATABASE.filter(c => c.brand.toLowerCase() === brand.toLowerCase());
}