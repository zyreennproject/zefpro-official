import React, { useState } from 'react';
import { ChevronDown, HelpCircle, ShieldCheck } from 'lucide-react';
import { FaqItem } from '../types';

// ==========================================================================
// DAFTAR TANYA JAWAB RESMI (DARI DATA.JS)
// ==========================================================================
const FAQ_LIST: (FaqItem & { category: string })[] = [
  {
    category: "Keamanan Akun",
    q: "Apakah memasang config atau patch ini aman dari banned?",
    a: "Sangat aman. Seluruh modifikasi visual, tema klub, dan file config FPS dari ZYREENN Official hanya bekerja pada rendering visual di sisi client (HP pemain) tanpa memanipulasi data kompetitif online server Konami."
  },
  {
    category: "Tutorial Android",
    q: "Bagaimana cara memasang patch di Android 13 atau Android 14 ke atas?",
    a: "Di Android 13/14+, sistem membatasi akses folder /Android/data. Kamu cukup menginstall aplikasi Shizuku atau MT Manager VIP yang telah kami sediakan di bagian Toolkit untuk membuka akses perizinan direktori tanpa perlu me-root HP."
  },
  {
    category: "Suhu & Performa HP",
    q: "Apakah file config ini bisa membuat smartphone menjadi panas?",
    a: "Tidak. Justru sebaliknya. Khususnya untuk Config Extreme Lowest dan Framerate Gen V2, beban rendering GPU dan resolusi partikel latar yang berat diturunkan sehingga HP menjadi lebih dingin, baterai lebih hemat, dan FPS terkunci stabil 60 FPS."
  },
  {
    category: "Pemesanan Lynk.id",
    q: "Bagaimana sistem pemesanan Config Custom via Lynk.id?",
    a: "Pemesanan diproses instan melalui portal Lynk.id resmi ZYREENN. Setelah menyelesaikan pembayaran, kamu akan langsung menerima link file konfigurasi resmi atau terhubung dengan admin untuk tuning khusus spesifikasi HP kamu."
  },
  {
    category: "Gameplay & Mode",
    q: "Apakah patch ini mendukung laga Online Divisi dan Mode Mabar Teman?",
    a: "Ya, 100% mendukung. Semua patch ZYREENN kompatibel penuh untuk bermain Mode Laga AI offline, Acara Tur, Laga Divisi Online, hingga mode mabar bersama teman tanpa kendala force close."
  }
];

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-12 md:py-20 bg-slate-950 relative overflow-hidden">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
        
        {/* Header Seksi */}
        <div className="max-w-2xl mb-10 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold tracking-wider uppercase text-red-500">
            <HelpCircle className="w-4 h-4" />
            <span>TANYA JAWAB POPULER</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            Pertanyaan yang Sering Diajukan
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Informasi penting seputar keamanan akun, panduan instalasi perizinan Android, dan tips menjaga suhu smartphone saat bermain eFootball.
          </p>
        </div>

        {/* ========================================================
            ACCORDION LIST FAQ
            ======================================================== */}
        <div className="space-y-3">
          {FAQ_LIST.map((faq, index) => {
            const isOpen = openIndex === index;

            return (
              <div
                key={index}
                className={`border rounded-2xl transition-all duration-200 overflow-hidden ${
                  isOpen
                    ? 'border-red-600/50 bg-slate-900 shadow-lg'
                    : 'border-slate-800/80 bg-slate-900/60 hover:border-slate-700'
                }`}
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(index)}
                  aria-expanded={isOpen}
                  className="w-full py-4 px-5 sm:px-6 flex items-center justify-between gap-4 text-left font-bold text-white text-sm sm:text-base focus-visible:outline-none"
                >
                  <span className="flex-1">{faq.q}</span>
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center border transition-transform duration-200 shrink-0 ${
                      isOpen
                        ? 'rotate-180 bg-red-600 text-white border-red-600'
                        : 'border-slate-700 text-slate-400'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-5 pt-1 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-slate-800 mt-1">
                    <p>{faq.a}</p>
                    <div className="mt-3 flex items-center gap-1.5 text-[11px] font-bold text-red-400">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Kategori: {faq.category}</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};