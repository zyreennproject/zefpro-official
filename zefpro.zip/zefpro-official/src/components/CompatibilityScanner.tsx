import React, { useState } from 'react';
import { Cpu, Zap, Search, ArrowRight, Sparkles, RotateCcw } from 'lucide-react';
import {
  CHIPSET_BRANDS,
  CHIPSET_DATABASE,
  TIER_RECOMMENDATIONS,
  searchChipsets,
  getChipsetsByBrand
} from '../utils/compatibility';
import { ChipsetItem, TierRecommendation } from '../types';

export const CompatibilityScanner: React.FC = () => {
  const [selectedBrand, setSelectedBrand] = useState<string>('');
  const [selectedChipsetId, setSelectedChipsetId] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [suggestions, setSuggestions] = useState<ChipsetItem[]>([]);

  // State Animasi Scanning
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanProgress, setScanProgress] = useState<number>(0);
  const [terminalText, setTerminalText] = useState<string>('MENYIAPKAN HARDWARE SCANNER...');
  const [scanResult, setScanResult] = useState<{
    chipset: ChipsetItem;
    recommendation: TierRecommendation;
  } | null>(null);

  // Filter daftar chipset berdasarkan brand terpilih
  const availableChipsets = selectedBrand
    ? getChipsetsByBrand(selectedBrand)
    : CHIPSET_DATABASE;

  // Tangani ketikan pada kolom pencarian langsung
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    if (query.trim().length > 1) {
      setSuggestions(searchChipsets(query));
    } else {
      setSuggestions([]);
    }
  };

  const handleSelectSuggestion = (chipset: ChipsetItem) => {
    setSelectedBrand(chipset.brand);
    setSelectedChipsetId(chipset.id);
    setSearchQuery(chipset.name);
    setSuggestions([]);
  };

  // Proses Pemindaian Laser Cyber
  const startScanning = () => {
    let targetChipset = CHIPSET_DATABASE.find((c) => c.id === selectedChipsetId);

    if (!targetChipset && searchQuery.trim()) {
      targetChipset = CHIPSET_DATABASE.find(
        (c) => c.name.toLowerCase() === searchQuery.trim().toLowerCase()
      ) || searchChipsets(searchQuery)[0];
    }

    if (!targetChipset) {
      alert("Silakan pilih brand & tipe chipset HP kamu terlebih dahulu!");
      return;
    }

    setScanResult(null);
    setIsScanning(true);
    setScanProgress(0);

    const steps = [
      { progress: 25, text: "MENGIDENTIFIKASI ARSITEKTUR CPU & GPU..." },
      { progress: 55, text: "MENGUKUR THERMAL THROTTLING & STABILITAS FPS..." },
      { progress: 85, text: "MENCOCOKKAN PRESET CONFIG EFOOTBALL OPTIMAL..." },
      { progress: 100, text: "PROSES SCANNING HARDWARE SELESAI!" },
    ];

    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < steps.length) {
        setScanProgress(steps[currentStep].progress);
        setTerminalText(steps[currentStep].text);
        currentStep++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setIsScanning(false);
          const recommendation = TIER_RECOMMENDATIONS[targetChipset!.tier];
          setScanResult({
            chipset: targetChipset!,
            recommendation: recommendation,
          });
        }, 400);
      }
    }, 450);
  };

  const scrollToConfig = () => {
    const el = document.getElementById('config');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="compatibility" className="py-12 md:py-20 bg-slate-950 relative overflow-hidden">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
        
        {/* Header Seksi */}
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <div className="inline-flex items-center gap-1.5 text-xs font-bold tracking-wider uppercase text-red-500">
            <Cpu className="w-4 h-4" />
            <span>COMPATIBILITY</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            Cek Chipset untuk Rekomendasi Config
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Pilih Brand Prosesor atau Ketik Nama Chipset Smartphone Kamu untuk Mengetahui Kelas Performa dan Preset Config eFootball yang Paling Cocok.
          </p>
        </div>

        {/* ========================================================
            FORM SELEKSI & PENCARIAN CHIPSET
            ======================================================== */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 sm:p-8 shadow-xl space-y-5">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* 1. Pilih Brand */}
            <div>
              <label htmlFor="brand-select" className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                1. Pilih Kategori / Brand Chipset
              </label>
              <select
                id="brand-select"
                value={selectedBrand}
                onChange={(e) => {
                  setSelectedBrand(e.target.value);
                  setSelectedChipsetId('');
                }}
                className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-700 bg-slate-950 text-white focus:outline-none focus:ring-2 focus:ring-red-500"
              >
                <option value="">— Semua Brand Chipset —</option>
                {CHIPSET_BRANDS.map((brand) => (
                  <option key={brand} value={brand}>{brand}</option>
                ))}
              </select>
            </div>

            {/* 2. Pilih Tipe Chipset */}
            <div>
              <label htmlFor="chipset-select" className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-1.5">
                2. Pilih Tipe Chipset HP Kamu
              </label>
              <select
                id="chipset-select"
                value={selectedChipsetId}
                onChange={(e) => {
                  setSelectedChipsetId(e.target.value);
                  const found = CHIPSET_DATABASE.find(c => c.id === e.target.value);
                  if (found) setSearchQuery(found.name);
                }}
                className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-700 bg-slate-950 text-white focus:outline-none focus:ring-2 focus:ring-red-500"
              >
                <option value="">— Pilih Chipset —</option>
                {availableChipsets.map((chipset) => (
                  <option key={chipset.id} value={chipset.id}>
                    {chipset.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="relative flex items-center justify-center my-2">
            <div className="border-t border-slate-800 w-full" />
            <span className="bg-slate-900 px-3 text-[11px] font-bold text-slate-500 uppercase tracking-widest absolute">
              ATAU KETIK NAMA CHIPSET
            </span>
          </div>

          {/* Kolom Pencarian Langsung */}
          <div className="relative">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={handleSearchChange}
                placeholder="Contoh: Snapdragon 870, Helio G99, Dimensity 7050, Exynos 1480..."
                className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-700 bg-slate-950 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500"
              />
              <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
            </div>

            {/* Rekomendasi Hasil Pencarian */}
            {suggestions.length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-1.5 bg-slate-900 border border-red-500/50 rounded-xl shadow-2xl max-h-48 overflow-y-auto z-20 divide-y divide-slate-800">
                {suggestions.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => handleSelectSuggestion(item)}
                    className="p-2.5 text-xs font-semibold text-slate-200 hover:bg-red-950/50 hover:text-red-400 cursor-pointer flex items-center justify-between"
                  >
                    <span>{item.name}</span>
                    <span className="text-[10px] font-mono text-slate-400">{item.brand}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Tombol Pemindaian Laser */}
          <div className="pt-2 text-center">
            <button
              type="button"
              disabled={isScanning}
              onClick={startScanning}
              className="w-full sm:w-auto px-8 py-3.5 text-sm font-extrabold text-white bg-red-600 hover:bg-red-700 disabled:bg-slate-700 rounded-xl shadow-lg shadow-red-600/30 transition-all flex items-center justify-center gap-2 mx-auto"
            >
              <Zap className="w-4 h-4 fill-white" />
              <span>{isScanning ? "SEDANG MEMINDAI..." : "SCAN CHIPSET SEKARANG"}</span>
            </button>
          </div>
        </div>

        {/* ========================================================
            ANIMASI CYBER HUD PEMINDAIAN LASER
            ======================================================== */}
        {isScanning && (
          <div className="mt-8 p-6 bg-slate-950 border border-red-600/50 rounded-2xl shadow-xl shadow-red-600/10 text-center space-y-4 animate-in fade-in duration-300">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-red-600/10 border border-red-500/40 flex items-center justify-center relative overflow-hidden">
              <Cpu className="w-8 h-8 text-red-500 animate-pulse" />
              <div className="absolute inset-x-0 h-1 bg-red-500 shadow-lg shadow-red-500 animate-bounce top-0" />
            </div>

            <div>
              <p className="text-xs font-mono font-bold text-red-500 uppercase tracking-widest">
                SCANNING... {scanProgress}%
              </p>
              <p className="text-xs text-slate-400 mt-1 font-mono">
                {terminalText}
              </p>
            </div>

            {/* Progress Bar Track */}
            <div className="w-full max-w-md mx-auto h-2 bg-slate-900 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-red-600 to-rose-500 transition-all duration-300 shadow-lg"
                style={{ width: `${scanProgress}%` }}
              />
            </div>
          </div>
        )}

        {/* ========================================================
            KARTU HASIL IDENTIFIKASI & REKOMENDASI TIER
            ======================================================== */}
        {scanResult && !isScanning && (
          <div className="mt-8 p-6 sm:p-8 bg-slate-900 border-2 border-red-600/80 rounded-2xl shadow-2xl animate-in zoom-in-95 duration-300 space-y-6">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-slate-800">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Hasil Identifikasi Hardware:
                </span>
                <h3 className="text-xl sm:text-2xl font-extrabold text-white flex items-center gap-2 mt-0.5">
                  <Cpu className="w-5 h-5 text-red-500" />
                  <span>{scanResult.chipset.name}</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">{scanResult.chipset.brand}</p>
              </div>

              {/* Tier Badge */}
              <div className="self-start sm:self-auto">
                <span className={`px-3.5 py-1.5 rounded-full text-xs font-black uppercase tracking-wider shadow-sm ${
                  scanResult.chipset.tier === 'HIGH'
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    : scanResult.chipset.tier === 'MID'
                    ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                    : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                }`}>
                  {scanResult.recommendation.tierBadge}
                </span>
              </div>
            </div>

            {/* Analisa Deskripsi */}
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-950 p-4 rounded-xl border border-slate-800">
              {scanResult.recommendation.deskripsi}
            </p>

            {/* Daftar Preset Config yang Direkomendasikan */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-red-400 mb-3 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Rekomendasi Config eFootball untuk Chipset Ini:</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {scanResult.recommendation.items.map((item, idx) => (
                  <div
                    key={idx}
                    onClick={scrollToConfig}
                    className="p-4 bg-slate-950 hover:border-red-500 border border-slate-800 rounded-xl cursor-pointer transition-all flex flex-col justify-between group shadow-md"
                  >
                    <div>
                      <div className="flex items-center justify-between text-[10px] font-mono font-bold mb-1">
                        <span className="text-red-500 uppercase">{item.type}</span>
                        <span className="text-slate-400">{item.subtext}</span>
                      </div>
                      <h5 className="text-sm font-bold text-white group-hover:text-red-400 transition-colors">
                        {item.nama}
                      </h5>
                    </div>

                    <div className="pt-3 mt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                      <span className="text-[11px] text-slate-400">Preset: <strong className="text-slate-200">{item.preset}</strong></span>
                      <span className="text-red-500 font-bold group-hover:translate-x-1 transition-transform flex items-center gap-0.5">
                        Pilih <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Tombol Reset */}
            <div className="pt-2 text-center">
              <button
                type="button"
                onClick={() => { setScanResult(null); setSearchQuery(''); setSelectedChipsetId(''); }}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-red-400 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset & Scan Chipset Lain</span>
              </button>
            </div>

          </div>
        )}

      </div>
    </section>
  );
};