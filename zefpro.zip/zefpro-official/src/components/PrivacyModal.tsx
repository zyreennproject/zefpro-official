import React, { useState } from 'react';
import { X, ShieldCheck } from 'lucide-react';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'privacy' | 'terms' | 'ads';
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'privacy',
}) => {
  const [activeTab, setActiveTab] = useState<'privacy' | 'terms' | 'ads'>(initialTab);

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
    >
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full max-h-[85vh] overflow-hidden shadow-2xl flex flex-col text-left text-white">
        
        {/* Header Modal */}
        <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-red-500" />
            <h3 className="text-base sm:text-lg font-extrabold text-white">
              Kebijakan Privasi & Kepatuhan Layanan
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Tutup Kebijakan Privasi"
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigasi */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-800 bg-slate-950/60">
          <button
            type="button"
            onClick={() => setActiveTab('privacy')}
            className={`pb-2.5 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'privacy'
                ? 'border-red-600 text-red-500'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Kebijakan Privasi
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('ads')}
            className={`pb-2.5 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'ads'
                ? 'border-red-600 text-red-500'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Kepatuhan Google Ads & Cookies
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('terms')}
            className={`pb-2.5 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'terms'
                ? 'border-red-600 text-red-500'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Syarat & Ketentuan Layanan
          </button>
        </div>

        {/* Isi Konten Scrollable */}
        <div className="p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
          
          {/* TAB 1: PRIVACY POLICY */}
          {activeTab === 'privacy' && (
            <>
              <h4 className="font-bold text-white text-sm">
                1. Pengumpulan & Penggunaan Data Pengunjung
              </h4>
              <p>
                ZYREENN Official sangat menghargai privasi setiap pengguna. Data yang Anda masukkan melalui formulir kontak atau konsultasi (nama/nickname, tipe smartphone, dan chipset) hanya digunakan semata-mata untuk memandu pemilihan file config yang presisi dan komunikasi teknis langsung melalui WhatsApp. Kami tidak pernah memperjualbelikan informasi Anda kepada pihak mana pun.
              </p>

              <h4 className="font-bold text-white text-sm pt-2">
                2. Keamanan File Unduhan
              </h4>
              <p>
                Semua tautan file patch, config, dan toolkit yang disediakan di situs ini telah melewati pengujian keamanan ketat, bebas dari virus, malware, maupun skrip berbahaya yang dapat merugikan perangkat smartphone Anda.
              </p>
            </>
          )}

          {/* TAB 2: ADSENSE & COOKIES COMPLIANCE */}
          {activeTab === 'ads' && (
            <>
              <h4 className="font-bold text-white text-sm">
                1. Penempatan Iklan & Kepatuhan Kebijakan AdSense
              </h4>
              <p>
                Website ZYREENN Official dirancang untuk mematuhi Google Publisher Policies secara ketat. Seluruh wadah iklan diberi label "SPONSORED / ADS" yang transparan, serta diletakkan pada jarak aman dari tombol unduhan untuk menghindari ketidaksengajaan klik (*accidental clicks*).
              </p>

              <h4 className="font-bold text-white text-sm pt-2">
                2. Penggunaan Cookie & Iklan Pihak Ketiga
              </h4>
              <p>
                Mitra periklanan pihak ketiga, termasuk Google, dapat menggunakan cookie (seperti Cookie DART) untuk menayangkan iklan yang relevan berdasarkan kunjungan Anda di situs web ini maupun situs web lain di internet. Anda dapat menonaktifkan personalisasi iklan kapan saja melalui Pengaturan Iklan Google.
              </p>

              <h4 className="font-bold text-white text-sm pt-2">
                3. Zero Cumulative Layout Shift (Zero CLS)
              </h4>
              <p>
                Setiap slot iklan memiliki ukuran tetap (728×90 / 320×50) sehingga saat iklan dimuat, tidak akan ada pergeseran tata letak yang mengganggu kenyamanan membaca para gamer.
              </p>
            </>
          )}

          {/* TAB 3: TERMS OF SERVICE */}
          {activeTab === 'terms' && (
            <>
              <h4 className="font-bold text-white text-sm">
                1. Penafian Hak Cipta & Non-Afiliasi (Disclaimer)
              </h4>
              <p>
                ZYREENN Official adalah wadah modifikasi independen berbasis riset komunitas dan <strong>tidak berafiliasi secara resmi dengan Konami Digital Entertainment Co., Ltd.</strong> Seluruh hak cipta, merek dagang, logo klub, dan aset original eFootball™ adalah milik masing-masing pemegang hak cipta aslinya.
              </p>

              <h4 className="font-bold text-white text-sm pt-2">
                2. Penggunaan Modifikasi & Config
              </h4>
              <p>
                Seluruh file modifikasi visual dan config yang disediakan di situs ini ditujukan untuk hiburan dan peningkatan performa bermain secara personal. Pengguna bertanggung jawab penuh atas penerapan file pada perangkat masing-masing.
              </p>

              <h4 className="font-bold text-white text-sm pt-2">
                3. Layanan Pemesanan Lynk.id
              </h4>
              <p>
                Pemesanan Config Custom VIP diproses melalui gateway resmi Lynk.id. File konfigurasi dan panduan tuning akan langsung diserahkan kepada pembeli setelah verifikasi pembayaran berhasil.
              </p>
            </>
          )}

        </div>

        {/* Footer Modal */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded-xl transition-colors"
          >
            Saya Mengerti
          </button>
        </div>

      </div>
    </div>
  );
};