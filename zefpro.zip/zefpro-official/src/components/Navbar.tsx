import React, { useState } from 'react';
import { Sun, Moon, Eye, EyeOff, Menu, X, ArrowUpRight } from 'lucide-react';

interface NavbarProps {
  isDark: boolean;
  toggleTheme: () => void;
  showAdSlots: boolean;
  toggleAdSlots: () => void;
  onOpenPrivacy: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  isDark,
  toggleTheme,
  showAdSlots,
  toggleAdSlots,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Navigasi Anchor Link Utama
  const navLinks = [
    { label: 'Patch', href: '#patch' },
    { label: 'Mods', href: '#mods' },
    { label: 'Config', href: '#config' },
    { label: 'Compatibility', href: '#compatibility' },
    { label: 'Toolkit', href: '#toolkit' },
    { label: 'FAQ', href: '#faq' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-slate-950/90 border-b border-slate-800/80 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          
          {/* Logo Murni webp ZYREENN (Tanpa Teks) */}
          <a
            href="#"
            className="flex items-center shrink-0 py-1"
            aria-label="Zyreenn"
          >
            <img
              src="src/assets/images/branding/logo.webp"
              alt="Zyreenn"
              className="h-8 sm:h-9 w-auto object-contain transition-transform hover:scale-105"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.onerror = null;
                target.src = '/assets/images/branding/logo.webp';
              }}
            />
          </a>

          {/* Navigasi Desktop */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-semibold text-slate-300">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="hover:text-red-500 transition-colors whitespace-nowrap relative py-1 after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-red-600 after:scale-x-0 hover:after:scale-x-100 after:transition-transform"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Aksi Kanan (Mode Iklan, Ganti Tema, CTA WA Admin) */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Tombol Saklar Pratinjau Slot Iklan */}
            <button
              type="button"
              onClick={toggleAdSlots}
              title={showAdSlots ? 'Sembunyikan Slot Iklan' : 'Tampilkan Slot Iklan'}
              aria-label="Toggle Ad Slot Preview"
              className={`hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                showAdSlots
                  ? 'bg-red-950/60 text-red-300 border-red-900'
                  : 'bg-slate-900 text-slate-400 border-slate-800'
              }`}
            >
              {showAdSlots ? <Eye className="w-3.5 h-3.5 text-red-500" /> : <EyeOff className="w-3.5 h-3.5" />}
              <span>{showAdSlots ? 'Ads: On' : 'Ads: Off'}</span>
            </button>

            {/* Tombol Dark / Light Mode */}
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={isDark ? 'Ganti ke Mode Terang' : 'Ganti ke Mode Gelap'}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-900 transition-colors shrink-0"
            >
              {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-300" />}
            </button>

            {/* Tombol Hubungi Admin via WhatsApp */}
            <a
              href="https://wa.me/6282291885416"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-sm hover:shadow-red-600/30 transition-all whitespace-nowrap shrink-0"
            >
              <span>Hubungi Admin</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>

            {/* Tombol Hamburger Mobile */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Buka menu navigasi"
              className="lg:hidden p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-900 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Drawer Menu Mobile */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-slate-800 bg-slate-950 px-4 pt-3 pb-5 space-y-3">
          <nav className="flex flex-col space-y-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 text-sm font-semibold text-slate-200 hover:bg-slate-900 rounded-lg transition-colors"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={toggleAdSlots}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg bg-slate-900 text-slate-300"
            >
              {showAdSlots ? <Eye className="w-3.5 h-3.5 text-red-500" /> : <EyeOff className="w-3.5 h-3.5" />}
              <span>{showAdSlots ? 'Ads On' : 'Ads Off'}</span>
            </button>

            <a
              href="https://wa.me/6282291885416"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileMenuOpen(false)}
              className="flex-1 text-center px-4 py-2 text-xs font-bold text-white bg-red-600 rounded-lg shadow-sm"
            >
              WhatsApp Admin
            </a>
          </div>
        </div>
      )}
    </header>
  );
};