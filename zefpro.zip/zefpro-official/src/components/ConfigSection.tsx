import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, X, ExternalLink, CheckCircle2, Zap, Download, ShoppingBag, Cpu } from 'lucide-react';
import { ItemDetailData } from '../types';

// ==========================================================================
// DATA CONFIG EFOOTBALL (DARI PAGES-DATA.JS)
// ==========================================================================
const CONFIG_ITEMS_DATA: Record<string, ItemDetailData> = {
  "detail-efconfig-1": {
    id: "detail-efconfig-1",
    isOrder: true,
    orderUrl: "http://lynk.id/zyreenn/drkk4jnmk1nm/checkout",
    detailSettings: { themeColor: "#FA0000", badgeText: "PAID VIP", badgeBg: "#FA0000" },
    header: {
      title: "CONFIG FRAMERATE GENERATION",
      version: "Latest Update",
      size: "-",
      author: "ZYREENN",
      date: "19 Oktober 2026",
      bannerImg: "src/assets/images/config/config-framerate-generation.webp",
      shortDesc: "Config yang Hadir untuk Memberikan Pengalaman Bermain eFootball yang Lebih Optimal dengan Fokus pada Kelancaran Gameplay, Kestabilan Performa, dan Kenyamanan Bermain. Menghadirkan Inovasi Frame Rate Generation Pertama Kali di Indonesia untuk Config eFootball, Dirancang untuk Membantu Perangkat Bekerja Lebih Efisien Sehingga Permainan Terasa Lebih Smooth, Responsif, dan Nyaman."
    },
    whatsNew: ["Fixed Bug", "Update V6.1.1"],
    featuresList: [
      "Add FrameRate Gen V2",
      "Add Thread RHI",
      "Add Swappy Frame Pacing Goggle",
      "Low Latency Time",
      "Penyesuaian Rendering & Texture",
      "AI Gameplay Improvements",
      "Add 100+ New Device Profile",
      "Tersedia 3 Preset"
    ],
    tutorialSteps: [
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" }
    ],
    downloads: {
      pengumuman: "Pemesanan resmi diproses instan melalui portal Lynk.id ZYREENN."
    }
  },

  "detail-efconfig-2": {
    id: "detail-efconfig-2",
    isOrder: true,
    orderUrl: "http://lynk.id/zyreenn/qx0rz46pzp1o/checkout",
    detailSettings: { themeColor: "#FA0000", badgeText: "PAID VIP", badgeBg: "#FA0000" },
    header: {
      title: "CONFIG PREMIUM MAX",
      version: "Latest Update",
      size: "-",
      author: "ZYREENN",
      date: "19 Oktober 2026",
      bannerImg: "src/assets/images/config/config-premium-max.webp",
      shortDesc: "Config yang Hadir Sebagai Solusi untuk Meningkatkan Kualitas Pengalaman Bermain eFootball dengan Performa yang Lebih Stabil, Responsif, dan Seimbang. dirancang untuk Mengoptimalkan Kinerja Perangkat serta Memberikan Gameplay yang Lebih Smooth dan Nyaman, dengan Tetap Memperhatikan Keseimbangan Antara Performa dan Kualitas Visual."
    },
    whatsNew: ["Fixed Bug", "Update V6.1.1"],
    featuresList: [
      "Add Thread Game",
      "Low Latency Time",
      "Swappy Frame Pacing UE",
      "Balance Rendering & Texture",
      "AI Gameplay Improvements",
      "Add 100+ New Device Profile",
      "Tersedia 3 Preset"
    ],
    tutorialSteps: [
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" }
    ],
    downloads: {
      pengumuman: "Pemesanan resmi diproses instan melalui portal Lynk.id ZYREENN."
    }
  },

  "detail-efconfig-3": {
    id: "detail-efconfig-3",
    isOrder: true,
    orderUrl: "http://lynk.id/zyreenn/vlwkx1g7nkdl/checkout",
    detailSettings: { themeColor: "#FA0000", badgeText: "PAID VIP", badgeBg: "#FA0000" },
    header: {
      title: "CONFIG EXTREME LOWEST",
      version: "Latest Update",
      size: "-",
      author: "ZYREENN",
      date: "19 Oktober 2026",
      bannerImg: "src/assets/images/config/config-extreme-lowest.webp",
      shortDesc: "Config yang Dirancang Khusus untuk Mengutamakan Performa Maksimal dengan Mengurangi Beban Kerja Perangkat saat Menjalankan eFootball. Menghadirkan Pengalaman Bermain yang Lebih Ringan, Responsif, dan Stabil, Sangat Cocok untuk Perangkat yang Membutuhkan Optimasi Performa Ekstra agar Gameplay Tetap Smooth dan Nyaman."
    },
    whatsNew: ["Fixed Bug", "Update V6.1.1"],
    featuresList: [
      "Performance Max",
      "Low Latency Time",
      "Add Chain GPU",
      "Swappy Frame Pacing UE",
      "Low Rendering & Texture",
      "AI Gameplay Improvements",
      "Add 100+ New Device Profile"
    ],
    tutorialSteps: [
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" }
    ],
    downloads: {
      pengumuman: "Pemesanan resmi diproses instan melalui portal Lynk.id ZYREENN."
    }
  },

  "detail-efconfig-4": {
    id: "detail-efconfig-4",
    isOrder: true,
    orderUrl: "https://wa.me/6282291885416?text=Halo%20Admin%20ZYREENN%2C%20Saya%20Ingin%20Konsultasi%20Sekaligus%20Memesan%20Config%20Custom",
    detailSettings: { themeColor: "#FA0000", badgeText: "CUSTOM TUNING", badgeBg: "#FA0000" },
    header: {
      title: "CONFIG CUSTOM REQUEST",
      version: "Latest Update",
      size: "-",
      author: "ZYREENN",
      date: "19 Oktober 2026",
      bannerImg: "src/assets/images/config/config-custom.webp",
      shortDesc: "Config yang Memberikan Kebebasan untuk Menyesuaikan Konfigurasi eFootball Sesuai dengan Kebutuhan dan Preferensi Perangkat Masing-masing. Setiap Permintaan akan dikerjakan Secara Khusus dengan Dukungan Revisi Gratis dan Layanan Prioritas untuk Memastikan Hasil Config Sesuai dengan Ekspektasi dan Kenyamanan Bermain."
    },
    whatsNew: ["Fixed Bug", "Update V6.1.1"],
    featuresList: [
      "Full Custom Request",
      "Free Revisi Config",
      "Priority Support"
    ],
    tutorialSteps: [
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" }
    ],
    downloads: {
      pengumuman: "Pemesanan resmi diproses instan melalui portal Lynk.id ZYREENN."
    }
  },

  "detail-efconfig-5": {
    id: "detail-efconfig-5",
    isOrder: false,
    detailSettings: { themeColor: "#10B981", badgeText: "FREE REGULER", badgeBg: "#10B981" },
    header: {
      title: "CONFIG REGULER",
      version: "Latest Update",
      size: "-",
      author: "ZYREENN",
      date: "19 Oktober 2026",
      bannerImg: "src/assets/images/config/config-reguler.webp",
      shortDesc: "Config Gratis Resmi ZYREENN untuk Mengatasi Lag Ringan dan Mengunci Kestabilan 60 FPS pada eFootball Mobile."
    },
    whatsNew: ["Fixed Bug", "V6.1.1"],
    featuresList: [
      "Gratis Unduh Langsung Tanpa Biaya",
      "Meringankan Beban Frame Rate",
      "Kompatibel untuk Semua Versi Android",
      "Pemasangan Praktis & Bersih"
    ],
    tutorialSteps: [
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" },
      { stepNumber: "", title: "", desc: "" }
    ],
    downloads: {
      nameDownload: "DIRECT DOWNLOAD",
      directUrl: " ",
      mediafire: " ",
      goggledrive: " ",
      modsfire: " ",
      sharemods: " ",
      pengumuman: "Gunakan Server Alternatif Jika Direct Download Sedang dalam Proses Update."
    }
  }
};

const CONFIG_LIST = Object.values(CONFIG_ITEMS_DATA);

export const ConfigSection: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedItem, setSelectedItem] = useState<ItemDetailData | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [brokenThumbnails, setBrokenThumbnails] = useState<Record<string, boolean>>({});

  const handleImageError = (id: string) => {
    setBrokenThumbnails((prev) => ({ ...prev, [id]: true }));
  };

  useEffect(() => {
    if (isPaused || CONFIG_LIST.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % CONFIG_LIST.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [isPaused]);

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % CONFIG_LIST.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + CONFIG_LIST.length) % CONFIG_LIST.length);
  };

  return (
    <section id="config" className="py-12 md:py-20 bg-slate-950 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Seksi */}
        <div className="max-w-3xl mb-8 text-left">
          <div className="flex items-center gap-2 text-xs font-bold tracking-wider uppercase text-red-500 mb-2">
            <Zap className="w-4 h-4" />
            <span>CONFIG</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            Koleksi Config eFootball
          </h2>
          <p className="mt-2 text-xs sm:text-sm text-slate-400">
            Tersedia Pilihan Config eFootball Paid Via Lynk.id serta Versi Reguler Free Download.
          </p>
        </div>

        {/* 3D Stacked Carousel Config */}
        <div
          className="relative min-h-[360px] sm:min-h-[440px] flex items-center justify-center overflow-hidden py-4"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          {CONFIG_LIST.map((item, index) => {
            let offset = index - currentIndex;
            if (offset < -Math.floor(CONFIG_LIST.length / 2)) {
              offset += CONFIG_LIST.length;
            } else if (offset > Math.floor(CONFIG_LIST.length / 2)) {
              offset -= CONFIG_LIST.length;
            }

            const isCenter = offset === 0;
            const isVisible = Math.abs(offset) <= 2;

            if (!isVisible) return null;

            const translateX = offset * 210;
            const scale = isCenter ? 1 : 0.84 - Math.abs(offset) * 0.08;
            const zIndex = 20 - Math.abs(offset) * 5;
            const opacity = isCenter ? 1 : 0.5 - Math.abs(offset) * 0.15;
            const rotateY = offset * -12;
            const hasImgError = brokenThumbnails[item.id];

            return (
              <div
                key={item.id}
                onClick={() => isCenter ? setSelectedItem(item) : setCurrentIndex(index)}
                style={{
                  transform: `translateX(${translateX}px) scale(${scale}) perspective(1000px) rotateY(${rotateY}deg)`,
                  zIndex: zIndex,
                  opacity: opacity,
                }}
                className={`absolute w-[290px] sm:w-[380px] md:w-[440px] aspect-[16/10] rounded-2xl overflow-hidden cursor-pointer bg-slate-900 border transition-all duration-500 ease-out select-none shadow-2xl flex flex-col justify-between ${
                  isCenter
                    ? 'border-red-600 shadow-red-600/25 ring-2 ring-red-600/40'
                    : 'border-slate-800/80'
                }`}
              >
                {/* Banner Thumbnail dengan Fallback Aman */}
                <div className="relative w-full h-full overflow-hidden bg-slate-950">
                  {!hasImgError ? (
                    <img
                      src={item.header.bannerImg}
                      alt={item.header.title}
                      onError={() => handleImageError(item.id)}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col justify-center items-center bg-gradient-to-br from-slate-900 via-slate-950 to-red-950 p-6 text-center text-white">
                      <Cpu className="w-10 h-10 text-red-500 mb-2" />
                      <span className="text-xs font-mono font-bold text-red-400">{item.detailSettings.badgeText}</span>
                      <h4 className="text-sm font-extrabold mt-1">{item.header.title}</h4>
                    </div>
                  )}
                  
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent pointer-events-none" />

                  {/* Badge Atas */}
                  <div className="absolute top-3 left-3 flex items-center gap-1.5">
                    <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded text-white shadow ${
                      item.isOrder ? 'bg-red-600' : 'bg-emerald-600'
                    }`}>
                      {item.detailSettings.badgeText}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-black/70 text-white backdrop-blur-sm">
                      {item.header.size}
                    </span>
                  </div>

                  {/* Info Bawah Card */}
                  <div className="absolute bottom-3 left-3 right-3 text-left">
                    <p className="text-xs font-mono font-bold text-red-400 mb-0.5">
                      {item.header.version} · {item.header.author}
                    </p>
                    <h3 className="text-base sm:text-lg font-extrabold text-white leading-tight truncate">
                      {item.header.title}
                    </h3>
                    <p className="text-[11px] text-slate-300 line-clamp-1 mt-1">
                      {item.header.shortDesc}
                    </p>
                  </div>
                </div>

                {/* Status Bar Bawah */}
                <div className="bg-slate-950 border-t border-slate-800 p-2.5 flex items-center justify-between text-xs text-white">
                  <span className="text-[11px] font-semibold text-slate-400">
                    {item.isOrder ? "Order Lynk.id Resmi" : "Direct Free Download"}
                  </span>
                  <span className="text-red-500 font-bold flex items-center gap-1">
                    Detail <ExternalLink className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}

          {/* Navigasi Kiri & Kanan */}
          <button
            type="button"
            onClick={handlePrev}
            aria-label="Sebelumnya"
            className="absolute left-2 sm:left-4 z-30 p-2.5 sm:p-3 rounded-full bg-slate-900/90 hover:bg-red-600 text-white border border-slate-800 hover:border-red-600 transition-colors shadow-lg"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={handleNext}
            aria-label="Selanjutnya"
            className="absolute right-2 sm:right-4 z-30 p-2.5 sm:p-3 rounded-full bg-slate-900/90 hover:bg-red-600 text-white border border-slate-800 hover:border-red-600 transition-colors shadow-lg"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Indikator Titik */}
        <div className="flex items-center justify-center gap-1.5 mt-3">
          {CONFIG_LIST.map((_, dotIdx) => (
            <button
              key={dotIdx}
              type="button"
              onClick={() => setCurrentIndex(dotIdx)}
              className={`h-1.5 rounded-full transition-all ${
                currentIndex === dotIdx ? 'w-6 bg-red-600' : 'w-2 bg-slate-800'
              }`}
            />
          ))}
        </div>

      </div>

      {/* ========================================================
          MODAL POP-UP DETAIL CONFIG
          ======================================================== */}
      {selectedItem && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
        >
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-5 sm:p-7 shadow-2xl text-left relative text-white">
            
            <button
              type="button"
              onClick={() => setSelectedItem(null)}
              aria-label="Tutup Detail"
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-red-600 transition-colors z-10"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-6">
              
              {/* Banner Atas Modal */}
              <div className="relative aspect-[16/9] rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
                <img
                  src={selectedItem.header.bannerImg}
                  alt={selectedItem.header.title}
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                  }}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3">
                  <span className={`text-xs font-extrabold uppercase px-2.5 py-1 rounded text-white shadow ${
                    selectedItem.isOrder ? 'bg-red-600' : 'bg-emerald-600'
                  }`}>
                    {selectedItem.detailSettings.badgeText}
                  </span>
                </div>
              </div>

              {/* Header Info */}
              <div>
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mb-1">
                  <span>Versi: <strong className="text-red-400">{selectedItem.header.version}</strong></span>
                  <span>·</span>
                  <span>Ukuran: <strong>{selectedItem.header.size}</strong></span>
                  <span>·</span>
                  <span>Tipe: <strong>{selectedItem.isOrder ? "Order Lynk.id" : "Free Download"}</strong></span>
                </div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-white">
                  {selectedItem.header.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
                  {selectedItem.header.shortDesc}
                </p>
              </div>

              {/* Fitur Utama */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
                  Fitur
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {selectedItem.featuresList.map((feature, fIdx) => (
                    <div key={fIdx} className="flex items-center gap-2 text-xs text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Blok Aksi: Order Lynk.id vs Free Download */}
              <div className="pt-4 border-t border-slate-800">
                {selectedItem.isOrder ? (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-red-400 font-bold uppercase tracking-wider">
                      <span>SISTEM PEMESANAN RESMI</span>
                      <span>LYNK.ID VERIFIED</span>
                    </div>

                    <a
                      href={selectedItem.orderUrl || "https://lynk.id/zyreenn"}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-3.5 px-4 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-extrabold text-sm rounded-xl shadow-lg shadow-red-600/30 transition-all flex items-center justify-center gap-2"
                    >
                      <ShoppingBag className="w-4 h-4" />
                      <span>ORDER VIA LYNK.ID SEKARANG</span>
                    </a>

                    <p className="text-[11px] text-slate-400 text-center">
                      Setelah pembayaran berhasil, file config resmi akan dikirimkan otomatis.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <span className="block text-xs font-bold uppercase tracking-wider text-emerald-400">
                      UNDUHAN CONFIG GRATIS
                    </span>

                    <a
                      href={selectedItem.downloads?.directUrl || "#"}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm rounded-xl shadow-lg shadow-emerald-600/20 transition-all flex items-center justify-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      <span>DIRECT DOWNLOAD</span>
                    </a>

                    <div className="grid grid-cols-2 gap-3">
                      <a
                        href={selectedItem.downloads?.mediafire || "#"}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 text-center"
                      >
                        MediaFire
                      </a>
                      
                      <a
                        href={selectedItem.downloads?.goggledrive || "#"}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 text-center"
                      >
                        Google Drive
                      </a>   
                                         
                      <a
                        href={selectedItem.downloads?.modsfire || "#"}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 text-center"
                      >
                        ModsFire
                      </a>
                      
                      <a
                        href={selectedItem.downloads?.sharemods || "#"}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 text-center"
                      >
                        ShareMods
                      </a>                  
                    </div>
                  </div>
                )}
              </div>

            </div>

          </div>
        </div>
      )}

    </section>
  );
};