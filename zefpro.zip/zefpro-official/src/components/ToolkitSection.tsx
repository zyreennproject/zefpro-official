import React, { useState } from 'react';
import { Download, Star, Wrench, FolderArchive } from 'lucide-react';
import { ToolkitItem } from '../types';

// ==========================================================================
// DATA TOOLKIT & APLIKASI PENDUKUNG (GRID KOMPAK 2 KOLOM HP / 3 KOLOM DESKTOP)
// ==========================================================================
const TOOLKIT_LIST: ToolkitItem[] = [
  {
    id: "tool-1",
    title: "ZArchiver Pro",
    version: "v1.0.8",
    size: "9 MB",
    rating: "4.8",
    iconImg: "src/assets/images/downloads/zarchiver.webp",
    shortDesc: "Ekstrak arsip .zip & .7z file patch besar dengan aman tanpa korup.",
    directUrl: "https://direct-download.zyreenn.official/files/eFootball-v6.1.1-Official.zip",
    detailRefId: "detail-tools-1"
  },
  {
    id: "tool-2",
    title: "MT Manager VIP",
    version: "v2.14.0",
    size: "40 MB",
    rating: "4.9",
    iconImg: "src/assets/images/downloads/mt-manager.webp",
    shortDesc: "Dual-window explorer untuk memindahkan file patch ke Android/data.",
    directUrl: "https://direct-download.zyreenn.official/files/eFootball-v6.1.1-Official.zip",
    detailRefId: "detail-tools-2"
  },
  {
    id: "tool-3",
    title: "X-plore File",
    version: "v4.38",
    size: "11.5 MB",
    rating: "4.7",
    iconImg: "src/assets/images/tools/tool-xplore.webp",
    shortDesc: "Struktur pohon direktori stabil untuk transfer file cache game besar.",
    directUrl: "https://direct-download.zyreenn.official/files/eFootball-v6.1.1-Official.zip",
    detailRefId: "detail-tools-3"
  },
  {
    id: "tool-4",
    title: "Shizuku No-Root",
    version: "v13.5.4",
    size: "6 MB",
    rating: "5.0",
    iconImg: "src/assets/images/downloads/shizuku.webp",
    shortDesc: "Buka akses izin folder /Android/data di Android 11–14+ tanpa root.",
    directUrl: "https://direct-download.zyreenn.official/files/eFootball-v6.1.1-Official.zip",
    detailRefId: "detail-tools-4"
  },
  {
    id: "tool-5",
    title: "FPS Monitor Pro",
    version: "v2.4.1",
    size: "5 MB",
    rating: "4.8",
    iconImg: "src/assets/images/downloads/framex.webp",
    shortDesc: "Pantau real-time 60–120 FPS, suhu baterai, dan kestabilan GPU saat match.",
    directUrl: "https://direct-download.zyreenn.official/files/eFootball-v6.1.1-Official.zip",
    detailRefId: "detail-tools-5"
  },
  {
    id: "tool-6",
    title: "Game Booster Pro",
    version: "v3.1.0",
    size: "8 MB",
    rating: "4.7",
    iconImg: "src/assets/images/downloads/framex.webp",
    shortDesc: "Bersihkan RAM latar belakang dan prioritaskan CPU clock game.",
    directUrl: "https://direct-download.zyreenn.official/files/eFootball-v6.1.1-Official.zip",
    detailRefId: "detail-tools-6"
  }
];

export const ToolkitSection: React.FC = () => {
  const [brokenImages, setBrokenImages] = useState<Record<string, boolean>>({});

  const handleImageError = (id: string) => {
    setBrokenImages((prev) => ({ ...prev, [id]: true }));
  };

  return (
    <section id="toolkit" className="py-12 md:py-20 bg-slate-950 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
        
        {/* Header Seksi */}
        <div className="max-w-3xl mb-8 space-y-2">
          <div className="flex items-center gap-2 text-xs font-bold tracking-wider uppercase text-red-500">
            <Wrench className="w-4 h-4" />
            <span>ALAT PENDUKUNG RESMI</span>
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
            Toolkit & Aplikasi Pendukung Game
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            Aplikasi pengelola file, bypass perizinan Android/data, dan monitoring FPS terbaik yang telah teruji untuk kelancaran pemasangan patch ZYREENN.
          </p>
        </div>

        {/* ========================================================
            GRID KOLOM KOMPAK: 2 KOLOM DI MOBILE & 3 KOLOM DI DESKTOP
            ======================================================== */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4 md:gap-6">
          {TOOLKIT_LIST.map((tool) => {
            const hasError = brokenImages[tool.id];

            return (
              <div
                key={tool.id}
                className="group relative bg-slate-900/60 border border-slate-800 hover:border-red-500/60 rounded-2xl p-3.5 sm:p-5 shadow-lg hover:shadow-red-600/10 hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  {/* Baris Atas: Ikon & Rating */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center shrink-0">
                      {!hasError ? (
                        <img
                          src={tool.iconImg}
                          alt={tool.title}
                          onError={() => handleImageError(tool.id)}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <FolderArchive className="w-5 h-5 text-red-500" />
                      )}
                    </div>

                    <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-950 border border-slate-800 text-slate-200 text-[10px] sm:text-xs font-bold font-mono">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <span>{tool.rating}</span>
                    </div>
                  </div>

                  {/* Judul & Versi */}
                  <div className="mb-1.5">
                    <h3 className="text-xs sm:text-base font-extrabold text-white group-hover:text-red-400 transition-colors truncate">
                      {tool.title}
                    </h3>
                    <span className="text-[10px] font-mono text-slate-500">
                      {tool.version} · {tool.size}
                    </span>
                  </div>

                  {/* Deskripsi Singkat (2 Baris Rapi) */}
                  <p className="text-[11px] sm:text-xs text-slate-400 leading-relaxed line-clamp-2 mb-4">
                    {tool.shortDesc}
                  </p>
                </div>

                {/* Tombol Unduh APK Langsung */}
                <div className="pt-3 border-t border-slate-800/80">
                  <a
                    href={tool.directUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2 px-3 text-[11px] sm:text-xs font-bold text-white bg-slate-800 hover:bg-red-600 rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3 h-3" />
                    <span>Download</span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};