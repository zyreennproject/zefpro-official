import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Zap, X, Sparkles } from 'lucide-react';

export const Hero: React.FC = () => {
  const [imageError, setImageError] = useState(false);
  const [tickerModalOpen, setTickerModalOpen] = useState(false);

  // Fungsi scroll mulus ke bagian scanner chipset atau patch
  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative pt-4 pb-10 md:pt-6 md:pb-16 bg-slate-950 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        {/* ========================================================
            1. HERO BANNER RESMI ZYREENN
            ======================================================== */}
        <div className="relative w-full rounded-2xl overflow-hidden border border-slate-800/80 shadow-2xl bg-slate-900 aspect-[21/9] sm:aspect-[24/8] flex items-center justify-center">
          {!imageError ? (
            <img
              src="src/assets/images/branding/banner.webp"
              alt="ZYREENN Official Banner"
              onError={() => setImageError(true)}
              className="w-full h-full object-cover transform hover:scale-102 transition-transform duration-700"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-r from-red-950 via-slate-900 to-black p-8 flex flex-col justify-center items-center text-center text-white">
              <span className="text-xs font-mono font-bold text-red-500 uppercase tracking-widest mb-1">
                ZYREENN OFFICIAL STUDIO
              </span>
              <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
                CENTRAL GAMING MODS & eFOOTBALL CONFIG
              </h2>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent pointer-events-none" />
        </div>

        {/* ========================================================
            2. INFO TERBARU TICKER BAR (SHIMMER ANIMATION)
            ======================================================== */}
        <div
          onClick={() => setTickerModalOpen(true)}
          role="button"
          tabIndex={0}
          title="Klik untuk melihat pengumuman resmi lengkap"
          className="group relative cursor-pointer overflow-hidden rounded-xl bg-slate-900/70 border border-slate-800/80 hover:border-red-500/60 p-3 sm:p-3.5 flex items-center gap-3 transition-all duration-300 shadow-lg"
        >
          {/* Badge Merah */}
          <span className="bg-red-600 text-white text-[11px] font-extrabold px-2.5 py-1 rounded-md shrink-0 flex items-center gap-1.5 shadow-sm">
            <Sparkles className="w-3.5 h-3.5" />
            <span>INFO TERBARU</span>
          </span>

          {/* Running Text */}
          <div className="flex-1 overflow-hidden">
            <p className="text-xs sm:text-sm font-medium text-slate-300 truncate group-hover:text-red-400 transition-colors">
              NEW WEBSITE UPDATE! Tampilan Baru, Chipset Scanner, Download Lebih Cepat & Pengalaman Gaming Lebih Smooth.
            </p>
          </div>

          <span className="text-[11px] font-semibold text-slate-500 group-hover:text-slate-300 shrink-0 hidden sm:inline">
            Baca Selengkapnya →
          </span>
        </div>

        {/* ========================================================
            3. TEASER CEK KOMPATIBILITAS CHIPSET (HERO CENTER)
            ======================================================== */}
        <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-6 sm:p-10 text-center relative overflow-hidden shadow-xl">
          <div className="max-w-3xl mx-auto space-y-4">
            
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-red-950/50 text-red-400 border border-red-900/50">
              <Zap className="w-3.5 h-3.5 fill-red-400" />
              <span>COMPATIBILITY</span>
            </div>

            <h1 className="text-2xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white leading-tight">
              Cek Chipset & Rekomendasi Config eFootball
            </h1>

            {/* Tombol CTA */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
              <button
                type="button"
                onClick={() => scrollToSection('compatibility')}
                className="w-full sm:w-auto px-7 py-3.5 text-sm font-bold text-white bg-red-600 hover:bg-red-700 rounded-xl shadow-lg shadow-red-600/30 transition-all flex items-center justify-center gap-2"
              >
                <Zap className="w-4 h-4 fill-white" />
                <span>SCAN SEKARANG</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => scrollToSection('patch')}
                className="w-full sm:w-auto px-6 py-3.5 text-sm font-bold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-all"
              >
                LIHAT PATCH & MODS
              </button>
            </div>

            {/* Trust Badges */}
            <div className="flex flex-wrap items-center justify-center gap-y-2 gap-x-6 text-xs text-slate-400 pt-4 border-t border-slate-800/80">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Support 63+ Chipset Android</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>100% Anti-Banned Safe</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Multi-Server Fast Download</span>
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* ========================================================
          MODAL POP-UP PENGUMUMAN RESMI TICKER
          ======================================================== */}
      {tickerModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
        >
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full max-h-[85vh] overflow-y-auto p-6 sm:p-7 shadow-2xl text-left relative">
            
            <button
              type="button"
              onClick={() => setTickerModalOpen(false)}
              aria-label="Tutup Pengumuman"
              className="absolute top-5 right-5 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-4">
              <div className="flex items-center gap-2 text-xs font-bold text-red-500 uppercase tracking-wider">
                <Zap className="w-4 h-4" />
                <span>Pengumuman Resmi ZYREENN</span>
              </div>

              <h3 className="text-xl font-extrabold text-white">
                Website Resmi ZYREENN Telah Diperbarui!
              </h3>

              <div className="text-xs sm:text-sm text-slate-300 leading-relaxed space-y-3 pt-2 border-t border-slate-800">
                <p>Halo Gamer! 👋</p>
                <p>Kami dengan bangga mengumumkan bahwa <strong>WEBSITE RESMI ZYREENN</strong> kini telah mendapatkan pembaruan besar dengan berbagai fitur baru, peningkatan performa, serta pengalaman pengguna yang lebih modern dan nyaman.</p>

                <p className="font-bold text-red-400">🚀 APA YANG BARU DI WEBSITE ZYREENN?</p>

                <ul className="list-disc pl-5 space-y-2 text-slate-300">
                  <li><strong>Chipset Scanner:</strong> Fitur pemindaian chipset untuk mengetahui rekomendasi Config yang paling sesuai dengan perangkat kamu.</li>
                  <li><strong>New 3D UI Showcase:</strong> Tampilan showcase Patch, Mods, dan Config dengan kartu 3D interaktif.</li>
                  <li><strong>Detail Modal Pop-Up:</strong> Lihat rincian fitur dan tutorial pemasangan instan tanpa berpindah halaman.</li>
                  <li><strong>Multiple Download Servers:</strong> Tersedia Direct Download serta alternatif server MediaFire dan Google Drive.</li>
                  <li><strong>Sistem Order Lynk.id:</strong> Pemesanan Config Custom VIP kini lebih cepat dan instan.</li>
                </ul>

                <p className="pt-2 text-xs text-slate-400 italic">
                  ZYREENN — BETTER PERFORMANCE, BETTER EXPERIENCE.
                </p>
              </div>

              <div className="pt-4 flex justify-end">
                <button
                  type="button"
                  onClick={() => setTickerModalOpen(false)}
                  className="px-5 py-2 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
                >
                  Tutup Pengumuman
                </button>
              </div>
            </div>

          </div>
        </div>
      )}
    </section>
  );
};