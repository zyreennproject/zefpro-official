import React from 'react';
import { ArrowUp, Youtube, Heart, MessageSquare } from 'lucide-react';

interface FooterProps {
  onOpenPrivacy: (tab?: 'privacy' | 'terms' | 'ads') => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenPrivacy }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-950 text-slate-400 py-14 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10 text-center">
        
        {/* ========================================================
            1. LOGO RESMI, DESKRIPSI & SOSIAL MEDIA (POSISI TENGAH)
            ======================================================== */}
        <div className="flex flex-col items-center justify-center space-y-4">
          
          {/* Logo Murni webp ZYREENN (Tanpa Teks) */}
          <a
            href="#"
            className="inline-block transition-transform hover:scale-105"
            aria-label="Kembali ke atas"
          >
            <img
              src="src/assets/images/branding/logo.webp"
              alt="ZYREENN Official"
              className="h-10 sm:h-12 w-auto object-contain mx-auto"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.onerror = null;
                target.src = '/assets/images/branding/logo.webp';
              }}
            />
          </a>

          {/* Deskripsi Singkat */}
          <p className="text-xs sm:text-sm text-slate-400 max-w-lg leading-relaxed mx-auto">
            Wadah modifikasi independen berbasis riset komunitas gaming. Berfokus pada kestabilan frame rate 60–120 FPS dan pembaruan patch grafis eFootball berkualitas.
          </p>

          {/* Tombol Media Sosial (Posisi Tengah) */}
          <div className="flex flex-wrap items-center justify-center gap-2.5 pt-2">
            <a
              href="https://www.youtube.com/@zyreenn"
              target="_blank"
              rel="noopener noreferrer"
              title="YouTube ZYREENN"
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-red-600 text-slate-300 hover:text-white border border-slate-800 hover:border-red-600 transition-all text-xs font-bold flex items-center gap-1.5 shadow-md"
            >
              <Youtube className="w-4 h-4" />
              <span>YouTube</span>
            </a>

            <a
              href="https://www.tiktok.com/@zyreennyt"
              target="_blank"
              rel="noopener noreferrer"
              title="TikTok ZYREENN"
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-red-600 text-slate-300 hover:text-white border border-slate-800 hover:border-red-600 transition-all text-xs font-bold flex items-center gap-1.5 shadow-md"
            >
              <span>TikTok</span>
            </a>

            <a
              href="https://saweria.co/zyreenn"
              target="_blank"
              rel="noopener noreferrer"
              title="Dukung Karya di Saweria"
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-amber-500 text-slate-300 hover:text-white border border-slate-800 hover:border-amber-500 transition-all text-xs font-bold flex items-center gap-1.5 shadow-md"
            >
              <Heart className="w-3.5 h-3.5 fill-current" />
              <span>Saweria</span>
            </a>

            <a
              href="https://wa.me/6282291885416"
              target="_blank"
              rel="noopener noreferrer"
              title="WhatsApp Admin"
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-emerald-600 text-slate-300 hover:text-white border border-slate-800 hover:border-emerald-600 transition-all text-xs font-bold flex items-center gap-1.5 shadow-md"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Admin WA</span>
            </a>
          </div>
        </div>

        {/* ========================================================
            2. NAVIGASI DISESUAIKAN PERSIS DENGAN NAVBAR
            ======================================================== */}
        <div className="pt-4 border-t border-slate-900">
          <nav className="flex flex-wrap items-center justify-center gap-5 sm:gap-8 text-xs sm:text-sm font-semibold text-slate-300">
            <a href="#patch" className="hover:text-red-500 transition-colors">Patch</a>
            <a href="#mods" className="hover:text-red-500 transition-colors">Mods</a>
            <a href="#config" className="hover:text-red-500 transition-colors">Config</a>
            <a href="#compatibility" className="hover:text-red-500 transition-colors">Compatibility</a>
            <a href="#toolkit" className="hover:text-red-500 transition-colors">Toolkit</a>
            <a href="#faq" className="hover:text-red-500 transition-colors">FAQ</a>
            <a href="#kontak" className="hover:text-red-500 transition-colors">Kontak</a>
          </nav>
        </div>

        {/* ========================================================
            3. DISCLAIMER KONAMI RESMI & KEBIJAKAN PRIVASI
            ======================================================== */}
        <div className="pt-6 border-t border-slate-900 space-y-5 text-xs text-slate-400">
          
          {/* Kotak Disclaimer Resmi */}
          <div className="max-w-3xl mx-auto p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-[11px] leading-relaxed">
            <p>
              <strong>Disclaimer:</strong> ZYREENN Official adalah wadah modifikasi independen berbasis riset komunitas dan <em>tidak berafiliasi secara resmi</em> dengan Konami Digital Entertainment Co., Ltd. Seluruh hak cipta, merek dagang, dan aset original eFootball™ adalah milik masing-masing pemegang hak cipta.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400 max-w-4xl mx-auto pt-2">
            <p>© 2026 ZYREENN Official. All Rights Reserved. Built for Gaming Community.</p>

            {/* Link Kebijakan Privasi & AdSense */}
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => onOpenPrivacy('privacy')}
                className="hover:text-red-500 transition-colors underline"
              >
                Kebijakan Privasi
              </button>
              <span>·</span>
              <button
                type="button"
                onClick={() => onOpenPrivacy('ads')}
                className="hover:text-red-500 transition-colors underline"
              >
                Kepatuhan Iklan
              </button>
              <span>·</span>
              <button
                type="button"
                onClick={() => onOpenPrivacy('terms')}
                className="hover:text-red-500 transition-colors underline"
              >
                Syarat & Ketentuan
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* Tombol Melayang Scroll Ke Atas */}
      <button
        type="button"
        onClick={scrollToTop}
        aria-label="Kembali ke atas"
        className="fixed bottom-5 right-5 z-30 p-3 rounded-full bg-slate-900 hover:bg-red-600 text-white border border-slate-800 hover:border-red-600 shadow-xl transition-all"
      >
        <ArrowUp className="w-4 h-4" />
      </button>
    </footer>
  );
};