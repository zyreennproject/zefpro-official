import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, X, Download, CheckCircle2, Sparkles, ExternalLink, Trophy } from 'lucide-react';
import { ItemDetailData } from '../types';

// ==========================================================================
// DATA LENGKAP PATCH & MODS (DARI PAGES-DATA.JS)
// ==========================================================================
const PATCH_MODS_DATA: Record<string, ItemDetailData> = {
  "detail-efpatch-1": {
    id: "detail-efpatch-1",
    detailSettings: { themeColor: "#FA0000", badgeText: "ORIGINAL PLAYSTORE", badgeBg: "#FA0000" },
    header: {
      title: "EFOOTBALL 2027 PATCH",
      version: "V6.1.1",
      size: "4.1 GB",
      author: "ZYREENN",
      date: "19 Oktober 2026",
      bannerImg: "src/assets/images/efootball/efootball-zyreennpatch.webp",
      shortDesc: "eFootball PlayStore Versi Patch Ini Sudah Di Optimalkan Lebih Baik Dari Versi Resminya dan Performa Yang Juga Meningkat Tanpa Penambahan Data Mods. (Full Original)"
    },
    whatsNew: ["Perbaikan Masalah", "Pengoptimalan Performa"],
    featuresList: [
      "Original Data PlayStore",
      "Support Mode AI & Mode Online",
      "Unlock Full Data Patch",
      "Peningkatan Performa & Frame Rate",
      "Include Files Config Stabilizer"
    ],
    tutorialSteps: [
      { stepNumber: "01", title: "Unduh File Patch", desc: "Klik tombol Direct Download di bawah dan simpan file .zip di memori HP." },
      { stepNumber: "02", title: "Buka File Manager", desc: "Ekstrak file arsip menggunakan ZArchiver atau MT Manager." },
      { stepNumber: "03", title: "Pindahkan Folder Data", desc: "Salin folder 'jp.konami.pesam' ke direktori: Android/data/." },
      { stepNumber: "04", title: "Mainkan Game", desc: "Buka eFootball dan nikmati patch resmi Playstore tanpa install ulang!" }
    ],
    downloads: {
      nameDownload: "DIRECT DOWNLOAD",
      directUrl: " ",
      mediafire: " ",
      goggledrive: " ",
      modsfire: " ",
      sharemods: " ",
      pengumuman: "Gunakan Server Alternatif Jika Direct Download Sedang dalam Proses Update."
    }
  },

  "detail-efpatch-2": {
    id: "detail-efpatch-2",
    detailSettings: { themeColor: "#0232FF", badgeText: "CHAMPIONS LEAGUE THEME", badgeBg: "#0232FF" },
    header: {
      title: "EFOOTBALL PATCH NEW UCL",
      version: "V6.1.1",
      size: "5 GB",
      author: "PROTTOY PATCH",
      date: "18 Oktober 2026",
      bannerImg: "src/assets/images/efootball/efootballpatch-5.webp",
      shortDesc: "EFOOTBALL PATCH NEW UCL Kali ini Menghadirkan Patch dengan Tema Champions League yang Membawa Nuansa Baru Bagi Player eFootball Mulai dari Scoreboard UCL, License Club ( Kit & Logo ), Tampilan UI, dan Masih Banyak Lagi. Jadi Langsung Aja Kalian Cobain, dan Rasakan Serunya."
    },
    whatsNew: ["Perbaikan Masalah", "Pengoptimalan Performa"],
    featuresList: [
      "Champions League Theme & Stadium",
      "Add UCLl Ball & WC Ball",
      "Add BGM / Soundtrack",
      "Updated Player Realface (Ronaldo 2008, Neymar Santos, Messi 2017)",
      "Updated Player Miniface (1500+)",
      "No Circle Player (Console Gameplay)",
      "Full License (Premier League, Serie A, La Liga)",
      "Update Logo & Kits Season 26/27"
    ],
    tutorialSteps: [
      { stepNumber: "01", title: "Unduh File UCL", desc: "Klik tombol direct download berkecepatan tinggi di bawah ini." },
      { stepNumber: "02", title: "Ekstrak Arsip", desc: "Buka file menggunakan ZArchiver hingga menghasilkan folder data game." },
      { stepNumber: "03", title: "Timpa File Game", desc: "Salin dan timpa ke direktori Android/data/jp.konami.pesam/files/." },
      { stepNumber: "04", title: "Mulai Bertanding", desc: "Jalankan eFootball dan rasakan atmosfer kompetisi klub terelite di dunia!" }
    ],
    downloads: {
      nameDownload: "DIRECT DOWNLOAD",
      directUrl: " ",
      mediafire: " ",
      goggledrive: " ",
      modsfire: " ",
      sharemods: " ",
      pengumuman: "Gunakan Server Alternatif Jika Direct Download Sedang dalam Proses Update."
    }
  },

  "detail-efpatch-3": {
    id: "detail-efpatch-3",
    detailSettings: { themeColor: "#FF007D", badgeText: "KARINA AESPA THEME", badgeBg: "#FF007D" },
    header: {
      title: "EFOOTBALL PATCH KARINA AESPA",
      version: "V6.1.1",
      size: "4.25 GB",
      author: "IDSPHONE",
      date: "16 Oktober 2026",
      bannerImg: "src/assets/images/efootball/efootballpatch-4.webp",
      shortDesc: "EFOOTBALL PATCH KARINA AESPA Kali ini Menghadirkan Patch dengan Tema K-Pop dari Karina Aespa yang Memiliki Tampilan Keren Terutama di Tampilan UI. Jadi Langsung Aja Kalian Cobain, dan Rasakan Serunya."
    },
    whatsNew: ["Perbaikan Masalah", "Pengoptimalan Performa"],
    featuresList: [
      "Karina Aespa Theme",
      "Add UCL Ball",
      "Original Grass & No Circle (Console Gameplay)",
      "Full License (Premier League, Serie A, La Liga)",
      "Add League Scottish Premiership (Classic Club)",
      "Add Liga 1 & 2 Indonesia",
      "Add BGM / Soundtrack",
      "Update Logo & Kits Season 26/27"
    ],
    tutorialSteps: [
      { stepNumber: "01", title: "Unduh Tema aespa", desc: "Dapatkan file melalui tombol unduh langsung di bawah." },
      { stepNumber: "02", title: "Ekstrak File", desc: "Ekstrak file arsip .zip menggunakan ZArchiver." },
      { stepNumber: "03", title: "Salin ke Android/data", desc: "Pindahkan ke /Android/data/jp.konami.pesam/." },
      { stepNumber: "04", title: "Selesai", desc: "Buka eFootball dan rasakan suasana lapangan bernuansa Next Level!" }
    ],
    downloads: {
      nameDownload: "DIRECT DOWNLOAD",
      directUrl: " ",
      mediafire: " ",
      goggledrive: " ",
      modsfire: " ",
      sharemods: " ",
      pengumuman: "Gunakan Server Alternatif Jika Direct Download Sedang dalam Proses Update."
    }
  },

  "detail-efpatch-4": {
    id: "detail-efpatch-4",
    detailSettings: { themeColor: "#E90052", badgeText: "ENGLISH PREMIER LEAGUE THEME", badgeBg: "#E90052" },
    header: {
      title: "EFOOTBALL PATCH EPL",
      version: "V6.1.1",
      size: "4.33 GB",
      author: "IDSPHONE",
      date: "16 Oktober 2026",
      bannerImg: "src/assets/images/efootball/efootballpatch-2.webp",
      shortDesc: "EFOOTBALL PATCH EPL Kali Ini Menghadirkan Patch dengan Tema English Premier League yang Khas Mulai dari Scoreboard, Tampilan UI dan Match Interface. Jadi Langsung Aja Kalian Cobain, dan Rasakan Serunya."
    },
    whatsNew: ["Perbaikan Masalah", "Pengoptimalan Performa"],
    featuresList: [
      "English Premier League Theme",
      "Mods Grass & Original Circle",
      "Full License (Premier League, Serie A, La Liga)",
      "Add Ball EPL",
      "Add 300+ Miniface Player",
      "Add League Scottish Premiership (Classic Club)",
      "Add Liga 1 & 2 Indonesia",
      "Add BGM / Soundtrack",
      "Update Logo & Kits Season 26/27"
    ],
    tutorialSteps: [
      { stepNumber: "01", title: "Unduh File EPL", desc: "Klik tombol direct download berkecepatan tinggi di bawah." },
      { stepNumber: "02", title: "Ekstrak Arsip .zip", desc: "Gunakan aplikasi ZArchiver untuk mengekstrak file arsip." },
      { stepNumber: "03", title: "Salin ke Android/data", desc: "Pindahkan ke /Android/data/jp.konami.pesam/files/ dan timpa file lama." },
      { stepNumber: "04", title: "Mulai Bermain", desc: "Nikmati persaingan liga sepak bola paling kompetitif di dunia!" }
    ],
    downloads: {
      nameDownload: "DIRECT DOWNLOAD",
      directUrl: " ",
      mediafire: " ",
      goggledrive: " ",
      modsfire: " ",
      sharemods: " ",
      pengumuman: "Gunakan Server Alternatif Jika Direct Download Sedang dalam Proses Update."
    }
  },

  "detail-efpatch-5": {
    id: "detail-efpatch-5",
    detailSettings: { themeColor: "#E9EB56", badgeText: "ORIGINAL THEME", badgeBg: "#E9EB56" },
    header: {
      title: "EFOOTBALL PATCH ORIGINAL",
      version: "V6.1.1",
      size: "4.13 GB",
      author: "IDSPHONE",
      date: "15 Oktober 2026",
      bannerImg: "src/assets/images/efootball/efootballpatch-3.webp",
      shortDesc: "EFOOTBALL PATCH ORIGINAL Kali ini Menghadirkan Patch dengan Tema Full Original Mulai Loading Screen, Tampilan UI, Scoreboard, dan Lainnya. Ini Patch Khusus Buat Kalian Yang Suka Tampilan Original. Buruan Kalian Cobain"
    },
    whatsNew: ["Perbaikan Masalah", "Pengoptimalan Performa"],
    featuresList: [
      "Original Theme",
      "Original Grass & Circle",
      "Full License (Premier League, Serie A, La Liga)",
      "Add Ball UCL",
      "Add League Scottish Premiership (Classic Club)",
      "Add Liga 1 & 2 Indonesia",
      "Update Logo & Kits Season 26/27"
    ],
    tutorialSteps: [
      { stepNumber: "01", title: "Unduh Patch Liga Indonesia", desc: "Klik tombol unduhan direct link di bawah." },
      { stepNumber: "02", title: "Ekstrak File", desc: "Ekstrak file arsip .zip menggunakan aplikasi ZArchiver." },
      { stepNumber: "03", title: "Timpa Folder Game", desc: "Pindahkan ke direktori /Android/data/jp.konami.pesam/." },
      { stepNumber: "04", title: "Selesai", desc: "Dukung klub kebanggaan daerahmu di eFootball Mobile!" }
    ],
    downloads: {
      nameDownload: "DIRECT DOWNLOAD",
      directUrl: " ",
      mediafire: " ",
      goggledrive: " ",
      modsfire: " ",
      sharemods: " ",
      pengumuman: "Gunakan Server Alternatif Jika Direct Download Sedang dalam Proses Update."
    }
  },
  
  "detail-efpatch-6": {
    id: "detail-efpatch-6",
    detailSettings: { themeColor: "#0232FF", badgeText: "CHAMPIONS LEAGUE THEME", badgeBg: "#0232FF" },
    header: {
      title: "EFOOTBALL PATCH UCL",
      version: "V6.1.1",
      size: "4.39 GB",
      author: "IDSPHONE",
      date: "15 Oktober 2026",
      bannerImg: "src/assets/images/efootball/efootballpatch-1.webp",
      shortDesc: "EFOOTBALL PATCH UCL Kali ini Menghadirkan Patch dengan Tema Champions League yang Membawa Nuansa Baru Bagi Player eFootball Mulai dari Scoreboard UCL, License Club (Kit & Logo), Tampilan UI, dan Masih Banyak Lagi. Jadi Langsung Aja Kalian Cobain, dan Rasakan Serunya."
    },
    whatsNew: ["Perbaikan Masalah", "Pengoptimalan Performa"],
    featuresList: [
      "Champions League Theme",
      "Add Ball (UCL, EPL, & LaLiga)",
      "Mods Grass & No Circle (Console Gameplay)",
      "Full License (Premier League, Serie A, La Liga)",
      "Add League Scottish Premiership (Classic Club)",
      "Add Liga 1 & 2 Indonesia",
      "Add BGM / Soundtrack",
      "Update Logo & Kits Season 26/27"
    ],
    tutorialSteps: [
      { stepNumber: "01", title: "Unduh Patch Liga Indonesia", desc: "Klik tombol unduhan direct link di bawah." },
      { stepNumber: "02", title: "Ekstrak File", desc: "Ekstrak file arsip .zip menggunakan aplikasi ZArchiver." },
      { stepNumber: "03", title: "Timpa Folder Game", desc: "Pindahkan ke direktori /Android/data/jp.konami.pesam/." },
      { stepNumber: "04", title: "Selesai", desc: "Dukung klub kebanggaan daerahmu di eFootball Mobile!" }
    ],
    downloads: {
      nameDownload: "DIRECT DOWNLOAD",
      directUrl: " ",
      mediafire: " ",
      goggledrive: " ",
      modsfire: " ",
      sharemods: " ",
      pengumuman: "Gunakan Server Alternatif Jika Direct Download Sedang dalam Proses Update."
    }
  },

  "detail-efmods-1": {
    id: "detail-efmods-1",
    detailSettings: { themeColor: "#E9EB56", badgeText: "FULL MODS UPDATE", badgeBg: "#E9EB56" },
    header: {
      title: "EFOOTBALL 2027 MODS",
      version: "v1.11.3",
      size: "74.22 MB",
      author: "KIPAS EFOOTBALL",
      date: "26 Oktober 2026",
      bannerImg: "src/assets/images/efootball/efootballmods-1.webp",
      shortDesc: "EFOOTBALL 2027 MODS Kali Ini Menghadirkan Versi Update Full Mods yang Sangat Menarik karena Memiliki Fitur Mods Berlimpah dan Pastinya Kalian Suka."
    },
    whatsNew: ["Perbaikan Masalah", "Pengoptimalan Performa"],
    featuresList: [
      "Mode Online & Offline",
      "Original Theme",
      "Unlimited Item (Coin & Token)",
      "Add Bursa Transfer",
      "Unlock All Team Assets (Player Card & Manager Card)"
    ],
    tutorialSteps: [
      { stepNumber: "01", title: "Unduh Mod Stabilizer", desc: "Dapatkan file instan melalui tombol direct link di bawah." },
      { stepNumber: "02", title: "Ekstrak Arsip", desc: "Buka file menggunakan ZArchiver atau MT Manager." },
      { stepNumber: "03", title: "Salin ke Android/data", desc: "Pindahkan isi folder mod ke /Android/data/jp.konami.pesam/." },
      { stepNumber: "04", title: "Mulai Laga Divisi", desc: "Buka eFootball dan rasakan kestabilan koneksi online yang prima!" }
    ],
    downloads: {
      nameDownload: "DIRECT DOWNLOAD",
      directUrl: " ",
      mediafire: " ",
      goggledrive: " ",
      modsfire: " ",
      sharemods: " ",
      pengumuman: "Gunakan Server Alternatif Jika Direct Download Sedang dalam Proses Update."
    }
  },

  "detail-efmods-2": {
    id: "detail-efmods-2",
    detailSettings: { themeColor: "#FFFFFF", badgeText: "CHINESE MODS", badgeBg: "#FFFFFF" },
    header: {
      title: "EFOOTBALL 2027 MODS",
      version: "V1.5",
      size: "2 GB",
      author: "EFOOTXI",
      date: "31 Oktober 2026",
      bannerImg: "src/assets/images/efootball/efootballmods-2.webp",
      shortDesc: "EFOOTBALL 2027 MODS kali Ini Menghadirkan Mods Versi China yang Fokus Pada Mode Offline dan Berbagai Pilihan Patch dalam Mods-nya."
    },
    whatsNew: ["Perbaikan Masalah", "Pengoptimalan Performa"],
    featuresList: [
      "Only Mode Offline",
      "Unlimited Item (Coin & Token)",
      "Unlock All Team Assets (Player Card & Manager Card)",
      "Full License (Premier League, Serie A, La Liga)",
      "Add Patch (UCL,EPL, & ORI)",
      "Add Ball (UCL, EPL, & LaLiga)",
      "Add 120FPS (Smooth Gameplay)",
      "Add BGM / Soundtrack",
      "Update Logo & Kits Season 26/27"
    ],
    tutorialSteps: [
      { stepNumber: "01", title: "Unduh Mod Offline", desc: "Klik tombol direct download di bawah." },
      { stepNumber: "02", title: "Ekstrak File", desc: "Ekstrak file arsip menggunakan ZArchiver." },
      { stepNumber: "03", title: "Pindahkan ke Android/data", desc: "Salin isi folder mod ke /Android/data/jp.konami.pesam/." },
      { stepNumber: "04", title: "Mainkan Mode Pesawat", desc: "Matikan internet dan mainkan eFootball secara offline kapan pun!" }
    ],
    downloads: {
      nameDownload: "DIRECT DOWNLOAD",
      directUrl: " ",
      mediafire: " ",
      goggledrive: " ",
      modsfire: " ",
      sharemods: " ",
      pengumuman: "Gunakan Server Alternatif Jika Direct Download Sedang dalam Proses Update."
    }
  }
};

const ITEMS_LIST = Object.values(PATCH_MODS_DATA);

export const PatchShowcase: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'patch' | 'mods'>('all');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedItem, setSelectedItem] = useState<ItemDetailData | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [brokenThumbnails, setBrokenThumbnails] = useState<Record<string, boolean>>({});

  const handleImageError = (id: string) => {
    setBrokenThumbnails((prev) => ({ ...prev, [id]: true }));
  };

  const filteredList = ITEMS_LIST.filter((item) => {
    if (activeTab === 'patch') return item.id.includes('efpatch');
    if (activeTab === 'mods') return item.id.includes('efmods');
    return true;
  });

  useEffect(() => {
    if (isPaused || filteredList.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % filteredList.length);
    }, 4500);
    return () => clearInterval(interval);
  }, [isPaused, filteredList.length]);

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % filteredList.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + filteredList.length) % filteredList.length);
  };

  return (
    <section id="patch" className="py-12 md:py-20 bg-slate-950 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Seksi */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-6 text-left">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 text-xs font-bold tracking-wider uppercase text-red-500 mb-2">
              <Sparkles className="w-4 h-4" />
              <span>PATCH & MODS</span>
            </div>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
              Koleksi eFootball Patch & eFootball Mods
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-400">
              Tersedia Banyak Pilihan Buat Kalian Cobain, Ayo Jelajahi Sekarang Dan Pilih Sesuai Gayamu
            </p>
          </div>

          {/* Tab Filter */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-900 rounded-xl border border-slate-800 self-start md:self-end">
            <button
              type="button"
              onClick={() => { setActiveTab('all'); setCurrentIndex(0); }}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                activeTab === 'all'
                  ? 'bg-red-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Semua Koleksi
            </button>
            <button
              type="button"
              onClick={() => { setActiveTab('patch'); setCurrentIndex(0); }}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                activeTab === 'patch'
                  ? 'bg-red-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              eFootball Patch
            </button>
            <button
              type="button"
              onClick={() => { setActiveTab('mods'); setCurrentIndex(0); }}
              className={`px-3.5 py-1.5 text-xs font-bold rounded-lg transition-colors ${
                activeTab === 'mods'
                  ? 'bg-red-600 text-white shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              eFootball Mods
            </button>
          </div>
        </div>

        {/* ========================================================
            3D STACKED CAROUSEL WRAPPER
            ======================================================== */}
        <div
          className="relative min-h-[360px] sm:min-h-[440px] flex items-center justify-center overflow-hidden py-4"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          {filteredList.map((item, index) => {
            let offset = index - currentIndex;
            if (offset < -Math.floor(filteredList.length / 2)) {
              offset += filteredList.length;
            } else if (offset > Math.floor(filteredList.length / 2)) {
              offset -= filteredList.length;
            }

            const isCenter = offset === 0;
            const isVisible = Math.abs(offset) <= 2;

            if (!isVisible) return null;

            const translateX = offset * 210;
            const scale = isCenter ? 1 : 0.84 - Math.abs(offset) * 0.08;
            const zIndex = 20 - Math.abs(offset) * 5;
            const opacity = isCenter ? 1 : 0.5 - Math.abs(offset) * 0.15;
            const rotateY = offset * -12;
            const hasImgError = brokenThumbnails[item.id];

            return (
              <div
                key={item.id}
                onClick={() => isCenter ? setSelectedItem(item) : setCurrentIndex(index)}
                style={{
                  transform: `translateX(${translateX}px) scale(${scale}) perspective(1000px) rotateY(${rotateY}deg)`,
                  zIndex: zIndex,
                  opacity: opacity,
                }}
                className={`absolute w-[290px] sm:w-[380px] md:w-[440px] aspect-[16/10] rounded-2xl overflow-hidden cursor-pointer bg-slate-900 border transition-all duration-500 ease-out select-none shadow-2xl flex flex-col justify-between ${
                  isCenter
                    ? 'border-red-600 shadow-red-600/25 ring-2 ring-red-600/40'
                    : 'border-slate-800/80'
                }`}
              >
                {/* Banner Thumbnail dengan Fallback Aman */}
                <div className="relative w-full h-full overflow-hidden bg-slate-950">
                  {!hasImgError ? (
                    <img
                      src={item.header.bannerImg}
                      alt={item.header.title}
                      onError={() => handleImageError(item.id)}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col justify-center items-center bg-gradient-to-br from-slate-900 to-red-950 p-6 text-center text-white">
                      <Trophy className="w-10 h-10 text-red-500 mb-2" />
                      <span className="text-xs font-mono font-bold text-red-400">{item.detailSettings.badgeText}</span>
                      <h4 className="text-sm font-extrabold mt-1">{item.header.title}</h4>
                    </div>
                  )}
                  
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent pointer-events-none" />

                  {/* Badge Atas */}
                  <div className="absolute top-3 left-3 flex items-center gap-1.5">
                    <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-red-600 text-white shadow">
                      {item.detailSettings.badgeText}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-black/70 text-white backdrop-blur-sm">
                      {item.header.size}
                    </span>
                  </div>

                  {/* Info Bawah Card */}
                  <div className="absolute bottom-3 left-3 right-3 text-left">
                    <p className="text-xs font-mono font-bold text-red-400 mb-0.5">
                      {item.header.version} · {item.header.author}
                    </p>
                    <h3 className="text-base sm:text-lg font-extrabold text-white leading-tight truncate">
                      {item.header.title}
                    </h3>
                    <p className="text-[11px] text-slate-300 line-clamp-1 mt-1">
                      {item.header.shortDesc}
                    </p>
                  </div>
                </div>

                {/* Status Bar Bawah */}
                <div className="bg-slate-950 border-t border-slate-800 p-2.5 flex items-center justify-between text-xs text-white">
                  <span className="text-[11px] font-semibold text-slate-400">
                    {isCenter ? "Klik untuk rincian & download" : "Klik untuk pilih"}
                  </span>
                  <span className="text-red-500 font-bold flex items-center gap-1">
                    Detail <ExternalLink className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}

          {/* Tombol Navigasi Slider */}
          <button
            type="button"
            onClick={handlePrev}
            aria-label="Sebelumnya"
            className="absolute left-2 sm:left-4 z-30 p-2.5 sm:p-3 rounded-full bg-slate-900/90 hover:bg-red-600 text-white border border-slate-800 hover:border-red-600 transition-colors shadow-lg"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <button
            type="button"
            onClick={handleNext}
            aria-label="Selanjutnya"
            className="absolute right-2 sm:right-4 z-30 p-2.5 sm:p-3 rounded-full bg-slate-900/90 hover:bg-red-600 text-white border border-slate-800 hover:border-red-600 transition-colors shadow-lg"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Indikator Titik Slider */}
        <div className="flex items-center justify-center gap-1.5 mt-3">
          {filteredList.map((_, dotIndex) => (
            <button
              key={dotIndex}
              type="button"
              onClick={() => setCurrentIndex(dotIndex)}
              className={`h-1.5 rounded-full transition-all ${
                currentIndex === dotIndex ? 'w-6 bg-red-600' : 'w-2 bg-slate-800'
              }`}
            />
          ))}
        </div>

      </div>

      {/* ========================================================
          MODAL POP-UP DETAIL LENGKAP
          ======================================================== */}
      {selectedItem && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
        >
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-5 sm:p-7 shadow-2xl text-left relative text-white">
            
            <button
              type="button"
              onClick={() => setSelectedItem(null)}
              aria-label="Tutup Detail"
              className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-red-600 transition-colors z-10"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-6">
              
              {/* Banner Atas Modal */}
              <div className="relative aspect-[16/9] rounded-xl overflow-hidden bg-slate-950 border border-slate-800">
                <img
                  src={selectedItem.header.bannerImg}
                  alt={selectedItem.header.title}
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                  }}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3">
                  <span className="text-xs font-extrabold uppercase px-2.5 py-1 rounded bg-red-600 text-white shadow">
                    {selectedItem.detailSettings.badgeText}
                  </span>
                </div>
              </div>

              {/* Header Info */}
              <div>
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mb-1">
                  <span>Versi: <strong className="text-red-400">{selectedItem.header.version}</strong></span>
                  <span>·</span>
                  <span>Ukuran: <strong>{selectedItem.header.size}</strong></span>
                  <span>·</span>
                  <span>Author: <strong>{selectedItem.header.author}</strong></span>
                </div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-white">
                  {selectedItem.header.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
                  {selectedItem.header.shortDesc}
                </p>
              </div>

              {/* Apa Yang Baru */}
              {selectedItem.whatsNew && selectedItem.whatsNew.length > 0 && (
                <div className="p-3.5 bg-slate-950/60 rounded-xl border border-slate-800">
                  <h4 className="text-xs font-bold text-red-400 uppercase tracking-wider mb-2">
                    Apa Yang Baru?
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedItem.whatsNew.map((item, idx) => (
                      <span key={idx} className="text-xs font-semibold px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-slate-200">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Fitur Utama */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
                  Fitur
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {selectedItem.featuresList.map((feature, fIdx) => (
                    <div key={fIdx} className="flex items-center gap-2 text-xs text-slate-300">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Blok Download Multi-Server */}
              <div className="pt-4 border-t border-slate-800 space-y-3">
                <span className="block text-xs font-bold uppercase tracking-wider text-red-400">
                  PORTAL UNDUHAN RESMI
                </span>

                <a
                  href={selectedItem.downloads?.directUrl || "#"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3.5 px-4 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700 text-white font-extrabold text-sm rounded-xl shadow-lg shadow-red-600/30 transition-all flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>DIRECT DOWNLOAD</span>
                </a>

                <div className="grid grid-cols-2 gap-3">
                  <a
                    href={selectedItem.downloads?.mediafire || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition-colors flex items-center justify-center"
                  >
                    <span>Server 1 (MediaFire)</span>
                  </a>

                  <a
                    href={selectedItem.downloads?.goggledrive || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition-colors flex items-center justify-center"
                  >
                    <span>Server 2 (Google Drive)</span>
                  </a>
                  
                  <a
                    href={selectedItem.downloads?.modsfire || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition-colors flex items-center justify-center"
                  >
                    <span>Server 3 (ModsFire)</span>
                  </a>
                  
                  <a
                    href={selectedItem.downloads?.sharemods || "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition-colors flex items-center justify-center"
                  >
                    <span>Server 4 (ShareMods)</span>
                  </a>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

    </section>
  );
};