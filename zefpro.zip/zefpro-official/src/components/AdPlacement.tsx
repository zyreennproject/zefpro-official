import React from 'react';

interface AdPlacementProps {
  format: 'leaderboard' | 'infeed' | 'rectangle';
  slotId: string;
  placementLabel: string;
  className?: string;
  showAdSlots: boolean;
}

export const AdPlacement: React.FC<AdPlacementProps> = ({
  format,
  slotId,
  placementLabel,
  className = '',
  showAdSlots,
}) => {
  // Jika saklar di Navbar dimatikan (Mode Ads: Off), jangan tampilkan slot iklan
  if (!showAdSlots) {
    return null;
  }

  // 1. Format Leaderboard (IAB 728x90 Desktop / 320x50 Mobile)
  if (format === 'leaderboard') {
    return (
      <aside aria-label="Sponsor Advertisement" className={`w-full max-w-5xl mx-auto px-4 my-6 ${className}`}>
        <div className="flex items-center justify-between text-[10px] font-mono tracking-widest text-slate-500 uppercase mb-1 px-1">
          <span>SPONSORED / ADS · {placementLabel}</span>
          <span>ID: {slotId}</span>
        </div>

        {/* Blok Iklan Permanen Bersih Tanpa Kode Cuplikan */}
        <div className="relative min-h-[90px] md:min-h-[100px] w-full bg-slate-900/80 border border-slate-800 rounded-xl flex items-center justify-center p-3 text-center overflow-hidden">
          <div className="flex flex-col items-center justify-center gap-1 text-slate-500">
            <span className="text-xs font-bold tracking-wider uppercase text-slate-400 font-mono">
              ADVERTISING PLACES
            </span>
            <span className="text-[11px] font-mono text-slate-500">
              IAB Standard 728×90 / 320×50 · Zero CLS
            </span>
          </div>
        </div>
      </aside>
    );
  }

  // 2. Format In-Feed Native Banner di Antara Konten
  return (
    <aside aria-label="Sponsor Advertisement" className={`w-full max-w-4xl mx-auto px-4 my-8 ${className}`}>
      <div className="flex items-center justify-between text-[10px] font-mono tracking-widest text-slate-500 uppercase mb-1.5 px-1">
        <span>SPONSORED / ADS · {placementLabel}</span>
        <span>ID: {slotId}</span>
      </div>

      <div className="relative min-h-[110px] md:min-h-[130px] bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
        <div className="space-y-1">
          <span className="inline-block text-[10px] font-bold uppercase tracking-wider text-red-500 font-mono">
            AREA MONETISASI RESMI
          </span>
          <h4 className="text-sm font-bold text-slate-200">
            Wadah Iklan In-Feed Native ZYREENN Official
          </h4>
          <p className="text-xs text-slate-400">
            Penempatan terstandarisasi dengan jarak aman dari tombol navigasi untuk mencegah salah klik.
          </p>
        </div>

        <div className="shrink-0 px-3.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-400">
          ID: {slotId}
        </div>
      </div>
    </aside>
  );
};