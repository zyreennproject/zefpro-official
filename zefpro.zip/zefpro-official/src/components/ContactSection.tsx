import React, { useState } from 'react';
import { Send, CheckCircle2, MessageSquare, ExternalLink, Zap, Users } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    deviceModel: '',
    topic: 'Konsultasi Config Custom Chipset',
    message: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) errs.name = 'Nama atau Nickname gamer wajib diisi.';
    if (!formData.deviceModel.trim()) errs.deviceModel = 'Tipe HP & Chipset wajib diisi (Contoh: Poco X3 Pro / Helio G99).';
    if (!formData.message.trim()) errs.message = 'Rincian kendala atau pesan wajib diisi.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const generateWhatsAppUrl = () => {
    const adminPhone = '6282291885416'; // Nomor Resmi Admin ZYREENN
    const text = encodeURIComponent(
      `Halo Admin ZYREENN Official! 👋\n\n` +
      `* Nama: ${formData.name}\n` +
      `* Tipe HP / Chipset: ${formData.deviceModel}\n` +
      `* Keperluan: ${formData.topic}\n\n` +
      `* Pesan / Kendala:\n${formData.message}\n\n` +
      `Mohon bantuannya min, terima kasih!`
    );
    return `https://wa.me/${adminPhone}?text=${text}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitted(true);
    window.open(generateWhatsAppUrl(), '_blank', 'noopener,noreferrer');
  };

  return (
    <section id="kontak" className="py-12 md:py-20 bg-slate-950 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-left">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12">
          
          {/* Kolom Kiri: Info Kontak & Saluran WhatsApp */}
          <div className="lg:col-span-5 space-y-6">
            <div className="flex items-center gap-2 text-xs font-bold tracking-wider uppercase text-red-500">
              <Zap className="w-4 h-4" />
              <span>KONSULTASI & BANTUAN RESMI</span>
            </div>

            <h2 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-white tracking-tight">
              Butuh Bantuan Pemasangan atau Order Config Custom?
            </h2>

            <p className="text-xs sm:text-sm md:text-base text-slate-300 leading-relaxed">
              Hubungi Admin ZYREENN langsung untuk konsultasi settingan grafik terbaik smartphone kamu, melaporkan link download bermasalah, atau order tuning manual.
            </p>

            {/* Saluran WhatsApp Komunitas Card */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-slate-900 border border-emerald-500/30 text-white space-y-3 shadow-lg">
              <div className="flex items-center gap-2 text-xs font-bold font-mono text-emerald-400 uppercase tracking-wider">
                <Users className="w-4 h-4" />
                <span>Saluran Resmi Komunitas</span>
              </div>
              <h4 className="text-base font-extrabold text-white">
                eFootball 2027 For Everyone
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                Dapatkan akses file update patch tercepat, link direct download paling awal tanpa antre, serta info rilis config eFootball langsung di smartphone kamu.
              </p>
              <a
                href="https://whatsapp.com/channel/0029Vb4qJgG9hXF1"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold rounded-xl transition-colors shadow-md"
              >
                <span>GABUNG SALURAN WHATSAPP</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Kontak Admin WhatsApp Langsung */}
            <div className="p-4 bg-slate-900/60 rounded-xl border border-slate-800 flex items-center gap-3.5 shadow-md">
              <div className="w-10 h-10 rounded-xl bg-red-950/50 text-red-500 flex items-center justify-center shrink-0">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Chat WhatsApp Admin
                </h4>
                <p className="text-sm font-extrabold text-white">
                  +62 822-9188-5416
                </p>
                <p className="text-[11px] text-slate-400">
                  Fast Respon · Aktif Setiap Hari
                </p>
              </div>
            </div>
          </div>

          {/* Kolom Kanan: Formulir Pemesanan & Pertanyaan */}
          <div className="lg:col-span-7">
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
              {isSubmitted ? (
                <div className="py-10 text-center space-y-4">
                  <div className="w-14 h-14 mx-auto rounded-full bg-emerald-950/50 text-emerald-400 flex items-center justify-center">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-extrabold text-white">
                    Pesan Siap Diteruskan ke WhatsApp!
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                    Terima kasih, <strong>{formData.name}</strong>. Aplikasi WhatsApp kamu telah dibuka untuk melanjutkan konsultasi langsung dengan Admin ZYREENN.
                  </p>

                  <div className="pt-3 flex flex-col sm:flex-row items-center justify-center gap-3">
                    <a
                      href={generateWhatsAppUrl()}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow transition-colors flex items-center gap-2"
                    >
                      <MessageSquare className="w-4 h-4" />
                      <span>Buka WhatsApp Lagi</span>
                    </a>

                    <button
                      type="button"
                      onClick={() => setIsSubmitted(false)}
                      className="px-4 py-2.5 text-xs font-semibold text-slate-300 bg-slate-800 rounded-xl hover:bg-slate-700 transition-colors"
                    >
                      Kirim Pesan Lain
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} noValidate className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="input-name" className="block text-xs font-bold text-slate-300 mb-1.5">
                        Nama / Nickname <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="input-name"
                        type="text"
                        placeholder="Contoh: Rian Gamer"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className={`w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border bg-slate-950 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500 ${
                          errors.name ? 'border-red-500' : 'border-slate-700'
                        }`}
                      />
                      {errors.name && <p className="text-[11px] text-red-500 mt-1">{errors.name}</p>}
                    </div>

                    <div>
                      <label htmlFor="input-device" className="block text-xs font-bold text-slate-300 mb-1.5">
                        Tipe HP & Chipset <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="input-device"
                        type="text"
                        placeholder="Contoh: Redmi Note 12 - Helio G99"
                        value={formData.deviceModel}
                        onChange={(e) => setFormData({ ...formData, deviceModel: e.target.value })}
                        className={`w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border bg-slate-950 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500 ${
                          errors.deviceModel ? 'border-red-500' : 'border-slate-700'
                        }`}
                      />
                      {errors.deviceModel && <p className="text-[11px] text-red-500 mt-1">{errors.deviceModel}</p>}
                    </div>
                  </div>

                  <div>
                    <label htmlFor="select-topic" className="block text-xs font-bold text-slate-300 mb-1.5">
                      Topik Konsultasi / Keperluan
                    </label>
                    <select
                      id="select-topic"
                      value={formData.topic}
                      onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                      className="w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-700 bg-slate-950 text-white focus:outline-none focus:ring-2 focus:ring-red-500"
                    >
                      <option value="Konsultasi Config Custom Chipset">Konsultasi Config Custom Chipset (VIP)</option>
                      <option value="Order Config via Lynk.id">Pertanyaan Order Config Lynk.id</option>
                      <option value="Lapor Link Download Rusak / Error">Lapor Link Download Rusak / Error</option>
                      <option value="Tanya Panduan Ekstrak ZArchiver">Tanya Panduan Ekstrak / Izin Android/data</option>
                      <option value="Request Patch eFootball Baru">Request Patch atau Tema Baru</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="textarea-message" className="block text-xs font-bold text-slate-300 mb-1.5">
                      Rincian Pesan / Kendala yang Dihadapi <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      id="textarea-message"
                      rows={4}
                      placeholder="Tuliskan kendala lag, drop frame di menit berapa, atau bantuan yang kamu perlukan..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className={`w-full px-3.5 py-2.5 text-xs sm:text-sm rounded-xl border bg-slate-950 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-red-500 ${
                        errors.message ? 'border-red-500' : 'border-slate-700'
                      }`}
                    />
                    {errors.message && <p className="text-[11px] text-red-500 mt-1">{errors.message}</p>}
                  </div>

                  <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <p className="text-[11px] text-slate-500">
                      Format pesan akan otomatis tersusun rapi di WhatsApp.
                    </p>

                    <button
                      type="submit"
                      className="w-full sm:w-auto px-7 py-3 bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md shadow-red-600/30 transition-all flex items-center justify-center gap-2"
                    >
                      <Send className="w-4 h-4" />
                      <span>Kirim ke WhatsApp Admin</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};